"""Tests: valid referral logic end-to-end, reward unlock threshold (rule #28)."""
from __future__ import annotations

from datetime import timedelta

import pytest

from app.database.models import MembershipStatus, ReferralStatus, RewardStatus, utcnow
from app.services import UnitOfWork


async def _make_user(uow: UnitOfWork, telegram_id: int, username: str = "u"):
    return await uow.user_repo.create_user(
        telegram_id=telegram_id, username=username, first_name="T", last_name=None, language_code="fa"
    )


class _AlwaysMember:
    async def check_membership(self, telegram_user_id):
        return MembershipStatus.MEMBER


async def _fully_validate_referral(uow: UnitOfWork, referrer, referred_telegram_id: int, username: str):
    referred = await _make_user(uow, referred_telegram_id, username)
    result = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    referral = result.referral
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)
    referral.eligible_at = utcnow() - timedelta(hours=1)
    referral.referred_user = referred
    await uow.referral_service.record_activity_progress(referral, completed_count=5)
    status = await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysMember())
    return referral, status


@pytest.mark.asyncio
async def test_referral_requires_all_conditions_for_valid(uow: UnitOfWork):
    referrer = await _make_user(uow, 8001, "referrer")
    referred = await _make_user(uow, 8002, "referred")
    result = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    referral = result.referral
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)
    referral.eligible_at = utcnow() - timedelta(hours=1)
    referral.referred_user = referred

    # Activities NOT completed yet -> must not become VALID even though 8h elapsed.
    status = await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysMember())
    assert status != ReferralStatus.VALID


@pytest.mark.asyncio
async def test_fifth_valid_referral_unlocks_reward(uow: UnitOfWork):
    referrer = await _make_user(uow, 8101, "referrer")

    for i in range(4):
        referral, status = await _fully_validate_referral(uow, referrer, 8200 + i, f"invitee{i}")
        assert status == ReferralStatus.VALID

    reward = await uow.reward_service.get_or_init_reward(referrer)
    assert reward.status == RewardStatus.LOCKED
    assert referrer.valid_referrals_count == 4

    # Fifth referral crosses the threshold.
    referral, status = await _fully_validate_referral(uow, referrer, 8299, "invitee_final")
    assert status == ReferralStatus.VALID
    assert referrer.valid_referrals_count == 5

    reward = await uow.reward_service.get_or_init_reward(referrer)
    assert reward.status == RewardStatus.UNLOCKED


@pytest.mark.asyncio
async def test_reward_stays_locked_below_threshold(uow: UnitOfWork):
    referrer = await _make_user(uow, 8301, "referrer")
    for i in range(3):
        await _fully_validate_referral(uow, referrer, 8400 + i, f"invitee{i}")

    assert referrer.valid_referrals_count == 3
    reward = await uow.reward_service.get_or_init_reward(referrer)
    assert reward.status == RewardStatus.LOCKED


@pytest.mark.asyncio
async def test_valid_referrals_count_self_heals_from_source_of_truth(uow: UnitOfWork):
    """The counter is always recomputed from actual VALID referral rows,
    never blindly incremented — this test forces a mismatch and confirms
    the recompute path corrects it."""
    referrer = await _make_user(uow, 8501, "referrer")
    await _fully_validate_referral(uow, referrer, 8600, "invitee0")

    # Corrupt the cached counter directly.
    referrer.valid_referrals_count = 999

    # Any subsequent validation recomputes it from the Referral table.
    await _fully_validate_referral(uow, referrer, 8601, "invitee1")
    assert referrer.valid_referrals_count == 2  # not 1000
