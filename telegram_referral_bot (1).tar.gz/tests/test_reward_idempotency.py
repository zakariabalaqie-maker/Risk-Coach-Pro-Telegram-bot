"""Tests: reward claim idempotency (rule #15, #28)."""
from __future__ import annotations

from datetime import timedelta

import pytest

from app.database.models import MembershipStatus, RewardStatus, utcnow
from app.services import UnitOfWork


async def _make_user(uow: UnitOfWork, telegram_id: int, username: str = "u"):
    return await uow.user_repo.create_user(
        telegram_id=telegram_id, username=username, first_name="T", last_name=None, language_code="fa"
    )


class _AlwaysMember:
    async def check_membership(self, telegram_user_id):
        return MembershipStatus.MEMBER


async def _unlock_reward_for(uow: UnitOfWork, referrer):
    for i in range(5):
        referred = await _make_user(uow, 9000 + i + id(referrer) % 1000, f"inv{i}{referrer.id}")
        result = await uow.referral_service.attribute_referral(
            new_user=referred, referral_code=referrer.referral_code, is_new_user=True
        )
        referral = result.referral
        await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
        await uow.referral_service.on_membership_confirmed(referred)
        referral.eligible_at = utcnow() - timedelta(hours=1)
        referral.referred_user = referred
        await uow.referral_service.record_activity_progress(referral, completed_count=5)
        await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysMember())


@pytest.mark.asyncio
async def test_claim_fails_while_locked(uow: UnitOfWork):
    referrer = await _make_user(uow, 9500, "referrer_locked")
    success, reward = await uow.reward_service.claim(referrer)
    assert success is False
    assert reward.status == RewardStatus.LOCKED


@pytest.mark.asyncio
async def test_claim_succeeds_exactly_once_when_unlocked(uow: UnitOfWork):
    referrer = await _make_user(uow, 9600, "referrer_unlock")
    await _unlock_reward_for(uow, referrer)

    reward = await uow.reward_service.get_or_init_reward(referrer)
    assert reward.status == RewardStatus.UNLOCKED

    success, reward = await uow.reward_service.claim(referrer)
    assert success is True
    assert reward.status == RewardStatus.CLAIMED
    assert reward.claimed_at is not None


@pytest.mark.asyncio
async def test_second_claim_is_idempotent_noop(uow: UnitOfWork):
    referrer = await _make_user(uow, 9700, "referrer_double")
    await _unlock_reward_for(uow, referrer)

    success1, reward1 = await uow.reward_service.claim(referrer)
    assert success1 is True
    first_claimed_at = reward1.claimed_at

    success2, reward2 = await uow.reward_service.claim(referrer)
    assert success2 is False
    assert reward2.status == RewardStatus.CLAIMED
    assert reward2.claimed_at == first_claimed_at  # unchanged — not re-claimed


@pytest.mark.asyncio
async def test_repeated_claim_attempts_flag_fraud(uow: UnitOfWork):
    referrer = await _make_user(uow, 9800, "referrer_fraud")
    await _unlock_reward_for(uow, referrer)

    await uow.reward_service.claim(referrer)  # first, legitimate claim
    await uow.reward_service.claim(referrer)  # second, suspicious repeat

    flags = await uow.fraud_repo.list_open_for_user(referrer.id)
    assert any(f.flag_type.value == "MULTIPLE_REWARD_CLAIM_ATTEMPT" for f in flags)


@pytest.mark.asyncio
async def test_concurrent_style_claims_only_one_succeeds(uow: UnitOfWork):
    """Simulates two near-simultaneous claim calls against the same reward row
    (both awaited in the same transaction here since SQLite/asyncio has no
    true concurrency in this test setup, but the compare-and-swap UPDATE in
    RewardRepository.try_claim is what makes this safe under real concurrency
    too — only one UPDATE can ever match status='UNLOCKED')."""
    referrer = await _make_user(uow, 9900, "referrer_race")
    await _unlock_reward_for(uow, referrer)

    results = []
    for _ in range(3):
        success, reward = await uow.reward_service.claim(referrer)
        results.append(success)

    assert results.count(True) == 1
    assert results.count(False) == 2
