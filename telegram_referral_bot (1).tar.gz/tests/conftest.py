"""
Shared pytest fixtures.

Each test gets a fresh in-memory SQLite database (StaticPool keeps it alive
for the engine's lifetime) so tests never interfere with each other or with
any real bot.db file.
"""
from __future__ import annotations

import os
from typing import AsyncIterator

import pytest
import pytest_asyncio

os.environ.setdefault("BOT_TOKEN", "123456:TESTTOKENTESTTOKENTESTTOKENTESTTOK")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")

from app.database import database as db_module
from app.database.models import Base
from app.services import UnitOfWork


@pytest_asyncio.fixture
async def db_session() -> AsyncIterator:
    """
    Fresh schema + fresh session per test. We reset the module-level engine
    singleton so each test function gets its own isolated in-memory DB
    (StaticPool keeps the single in-memory connection alive across the
    session/engine lifetime, but we tear it down after every test).
    """
    await db_module.dispose_engine()
    engine = db_module.get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = db_module.get_session_factory()
    session = session_factory()
    try:
        yield session
        await session.rollback()
    finally:
        await session.close()
        await db_module.dispose_engine()


@pytest_asyncio.fixture
async def uow(db_session) -> UnitOfWork:
    return UnitOfWork(db_session)


@pytest.fixture
def anyio_backend():
    return "asyncio"
