"""Tests: admin authorization middleware (rule #16, #23, #28)."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from aiogram.types import CallbackQuery, Message

from app.bot.middlewares.admin_auth import AdminAuthMiddleware
from app.config import get_settings


def _fake_callback_query(user_id: int) -> CallbackQuery:
    """A MagicMock specced against the real aiogram CallbackQuery class, so
    isinstance() checks inside the middleware behave exactly as they would
    against a real Update — this is what makes the notify-on-reject branch
    genuinely exercised rather than silently skipped."""
    cb = MagicMock(spec=CallbackQuery)
    cb.from_user = MagicMock(id=user_id)
    cb.answer = AsyncMock()
    return cb


def _fake_message(user_id: int) -> Message:
    msg = MagicMock(spec=Message)
    msg.from_user = MagicMock(id=user_id)
    msg.answer = AsyncMock()
    return msg


@pytest.fixture(autouse=True)
def _set_admin_ids(monkeypatch):
    monkeypatch.setenv("ADMIN_IDS", "111,222")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.mark.asyncio
async def test_admin_middleware_allows_configured_admin():
    middleware = AdminAuthMiddleware()
    handler = AsyncMock(return_value="handled")
    fake_cb = _fake_callback_query(111)

    result = await middleware(handler, fake_cb, {"event_from_user": fake_cb.from_user})

    handler.assert_awaited_once()
    assert result == "handled"
    fake_cb.answer.assert_not_awaited()


@pytest.mark.asyncio
async def test_admin_middleware_rejects_non_admin_callback_and_notifies():
    middleware = AdminAuthMiddleware()
    handler = AsyncMock(return_value="handled")
    fake_cb = _fake_callback_query(999)  # not in ADMIN_IDS

    result = await middleware(handler, fake_cb, {"event_from_user": fake_cb.from_user})

    handler.assert_not_awaited()
    assert result is None
    fake_cb.answer.assert_awaited_once()
    _, kwargs = fake_cb.answer.call_args
    assert kwargs.get("show_alert") is True


@pytest.mark.asyncio
async def test_admin_middleware_rejects_non_admin_message_and_notifies():
    middleware = AdminAuthMiddleware()
    handler = AsyncMock(return_value="handled")
    fake_msg = _fake_message(999)

    result = await middleware(handler, fake_msg, {"event_from_user": fake_msg.from_user})

    handler.assert_not_awaited()
    assert result is None
    fake_msg.answer.assert_awaited_once()


@pytest.mark.asyncio
async def test_admin_middleware_rejects_missing_user():
    middleware = AdminAuthMiddleware()
    handler = AsyncMock(return_value="handled")
    fake_msg = _fake_message(0)

    result = await middleware(handler, fake_msg, {"event_from_user": None})

    handler.assert_not_awaited()
    assert result is None


def test_admin_id_set_parses_comma_separated_env(monkeypatch):
    monkeypatch.setenv("ADMIN_IDS", "111, 222,333")
    get_settings.cache_clear()
    settings = get_settings()
    assert settings.admin_id_set == {111, 222, 333}
    get_settings.cache_clear()


def test_admin_id_set_empty_by_default(monkeypatch):
    monkeypatch.delenv("ADMIN_IDS", raising=False)
    get_settings.cache_clear()
    settings = get_settings()
    assert settings.admin_id_set == set()
    get_settings.cache_clear()


@pytest.mark.asyncio
async def test_admin_router_is_registered_with_auth_middleware():
    """Structural check: main.build_dispatcher() must attach AdminAuthMiddleware
    to the admin router's message and callback_query observers — this is what
    actually protects the /admin command and all adm: callbacks at runtime."""
    from app.bot.handlers.admin import router as admin_router
    from app.main import build_dispatcher

    build_dispatcher()

    message_middlewares = [type(m).__name__ for m in admin_router.message.middleware]
    callback_middlewares = [type(m).__name__ for m in admin_router.callback_query.middleware]

    assert "AdminAuthMiddleware" in message_middlewares
    assert "AdminAuthMiddleware" in callback_middlewares
