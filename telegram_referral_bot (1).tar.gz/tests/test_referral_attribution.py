"""Tests: referral attribution, self-referral, duplicate referral, immutability (rule #28)."""
from __future__ import annotations

import pytest

from app.services import UnitOfWork


async def _make_user(uow: UnitOfWork, telegram_id: int, username: str = "u"):
    return await uow.user_repo.create_user(
        telegram_id=telegram_id, username=username, first_name="T", last_name=None, language_code="fa"
    )


@pytest.mark.asyncio
async def test_basic_attribution_succeeds(uow: UnitOfWork):
    referrer = await _make_user(uow, 1001, "referrer")
    referred = await _make_user(uow, 1002, "referred")

    result = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )

    assert result.rejected_reason is None
    assert result.referral is not None
    assert result.referral.referrer_id == referrer.id
    assert result.referral.referred_user_id == referred.id
    assert referred.referred_by_id == referrer.id


@pytest.mark.asyncio
async def test_self_referral_is_rejected(uow: UnitOfWork):
    user = await _make_user(uow, 2001, "self")

    result = await uow.referral_service.attribute_referral(
        new_user=user, referral_code=user.referral_code, is_new_user=False
    )

    assert result.rejected_reason == "self_referral"
    assert result.referral is None
    assert user.referred_by_id is None


@pytest.mark.asyncio
async def test_invalid_referral_code_is_handled(uow: UnitOfWork):
    user = await _make_user(uow, 3001, "newbie")

    result = await uow.referral_service.attribute_referral(
        new_user=user, referral_code="NOTAREALCODE", is_new_user=True
    )

    assert result.rejected_reason == "invalid_code"
    assert result.referral is None
    assert user.referred_by_id is None


@pytest.mark.asyncio
async def test_attribution_is_immutable_after_first_registration(uow: UnitOfWork):
    referrer_a = await _make_user(uow, 4001, "referrer_a")
    referrer_b = await _make_user(uow, 4002, "referrer_b")
    referred = await _make_user(uow, 4003, "referred")

    first = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer_a.referral_code, is_new_user=True
    )
    assert first.referral is not None
    original_referral_id = first.referral.id

    # Existing user tries to attribute to a DIFFERENT referrer later — must be a no-op.
    second = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer_b.referral_code, is_new_user=False
    )

    assert second.referral is not None
    assert second.referral.id == original_referral_id
    assert referred.referred_by_id == referrer_a.id  # unchanged


@pytest.mark.asyncio
async def test_no_duplicate_referral_row_created(uow: UnitOfWork):
    referrer = await _make_user(uow, 5001, "referrer")
    referred = await _make_user(uow, 5002, "referred")

    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )

    # Simulate a second /start with the same referral code from the same user.
    result = await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=False
    )

    all_referrals = await uow.referral_repo.list_by_referrer(referrer.id)
    assert len(all_referrals) == 1
    assert result.referral.id == all_referrals[0].id


@pytest.mark.asyncio
async def test_referral_code_generation_is_unique(uow: UnitOfWork):
    users = [await _make_user(uow, 6000 + i, f"user{i}") for i in range(20)]
    codes = {u.referral_code for u in users}
    assert len(codes) == 20  # no collisions
    for code in codes:
        assert code.startswith("REF")
        assert len(code) == 11  # "REF" + 8 chars
