"""Tests: 8-hour eligibility calculation and membership-driven transitions (rule #28)."""
from __future__ import annotations

from datetime import timedelta

import pytest

from app.database.models import MembershipStatus, ReferralStatus, as_aware_utc, utcnow
from app.services import UnitOfWork


async def _make_user(uow: UnitOfWork, telegram_id: int, username: str = "u"):
    return await uow.user_repo.create_user(
        telegram_id=telegram_id, username=username, first_name="T", last_name=None, language_code="fa"
    )


@pytest.mark.asyncio
async def test_eligible_at_is_joined_at_plus_membership_hours(uow: UnitOfWork):
    referrer = await _make_user(uow, 7001, "referrer")
    referred = await _make_user(uow, 7002, "referred")
    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )

    settings = await uow.campaign_settings_service.get()
    assert settings.membership_hours == 8  # default

    before = utcnow()
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)
    after = utcnow()

    referral = await uow.referral_repo.get_by_referred_user_id(referred.id)
    assert referral.status == ReferralStatus.JOINED
    assert referral.joined_at is not None
    assert referral.eligible_at is not None

    expected_min = before + timedelta(hours=8)
    expected_max = after + timedelta(hours=8)
    actual = as_aware_utc(referral.eligible_at)
    assert expected_min <= actual <= expected_max


@pytest.mark.asyncio
async def test_membership_hours_is_configurable_without_code_change(uow: UnitOfWork):
    await uow.campaign_settings_service.update(membership_hours=2)

    referrer = await _make_user(uow, 7101, "referrer")
    referred = await _make_user(uow, 7102, "referred")
    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)

    referral = await uow.referral_repo.get_by_referred_user_id(referred.id)
    delta = as_aware_utc(referral.eligible_at) - as_aware_utc(referral.joined_at)
    assert abs(delta.total_seconds() - 2 * 3600) < 5


class _AlwaysMember:
    async def check_membership(self, telegram_user_id):
        return MembershipStatus.MEMBER


class _AlwaysLeft:
    async def check_membership(self, telegram_user_id):
        return MembershipStatus.LEFT


@pytest.mark.asyncio
async def test_evaluate_referral_before_8h_stays_waiting(uow: UnitOfWork):
    referrer = await _make_user(uow, 7201, "referrer")
    referred = await _make_user(uow, 7202, "referred")
    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)

    referral = await uow.referral_repo.get_by_referred_user_id(referred.id)
    referral.referred_user = referred  # ensure relationship is populated for evaluate_referral

    status = await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysMember())
    assert status in (ReferralStatus.JOINED, ReferralStatus.WAITING_8_HOURS)
    assert status != ReferralStatus.VALID


@pytest.mark.asyncio
async def test_evaluate_referral_after_8h_with_activities_becomes_valid(uow: UnitOfWork):
    referrer = await _make_user(uow, 7301, "referrer")
    referred = await _make_user(uow, 7302, "referred")
    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)

    referral = await uow.referral_repo.get_by_referred_user_id(referred.id)
    referral.eligible_at = utcnow() - timedelta(hours=1)  # simulate elapsed time
    referral.referred_user = referred

    await uow.referral_service.record_activity_progress(referral, completed_count=5)

    status = await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysMember())
    assert status == ReferralStatus.VALID
    assert referral.validated_at is not None


@pytest.mark.asyncio
async def test_evaluate_referral_leaving_channel_marks_left(uow: UnitOfWork):
    referrer = await _make_user(uow, 7401, "referrer")
    referred = await _make_user(uow, 7402, "referred")
    await uow.referral_service.attribute_referral(
        new_user=referred, referral_code=referrer.referral_code, is_new_user=True
    )
    await uow.user_repo.set_membership_status(referred, MembershipStatus.MEMBER)
    await uow.referral_service.on_membership_confirmed(referred)

    referral = await uow.referral_repo.get_by_referred_user_id(referred.id)
    referral.referred_user = referred

    status = await uow.referral_service.evaluate_referral(referral, membership_service=_AlwaysLeft())
    assert status == ReferralStatus.LEFT
    assert referral.left_at is not None
