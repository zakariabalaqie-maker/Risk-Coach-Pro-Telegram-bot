# Telegram Viral Referral Bot — Expert Advisor Campaign

A production-ready, database-driven Telegram bot that distributes a $2,000
Expert Advisor for free to traders who complete a 5-referral viral campaign.
Everything — onboarding, channel-membership verification, the 5-question
trader profile, referral tracking, the 8-hour eligibility window, fraud
flagging, reward unlocking, and a full admin panel — runs **inside Telegram**
via inline keyboards. No Mini App, no website, no domain required.

---

## 1. Architecture Summary

**Server-side, database-driven, restart-safe.** Nothing important is ever
held only in a Telegram message, a client, or in-memory FSM state — every
fact needed to resume the campaign (membership status, referral state,
question answers, reward status) lives in SQLite (or PostgreSQL later) and
survives a bot restart untouched.

**Layered design:**

```
Telegram Update
      |
      v
Middlewares (DB session -> user context/block check -> throttling -> [admin auth])
      |
      v
Handlers (thin -- parse input, call services, render keyboards/text)
      |
      v
Services (business logic: ReferralService state machine, RewardService
          idempotent claims, FraudService detection, ProfileService scoring,
          MembershipService Telegram API wrapper, CampaignSettingsService)
      |
      v
Repositories (pure data access, no business logic)
      |
      v
SQLAlchemy 2.x async ORM --> SQLite (MVP) / PostgreSQL (future, same code)
```

A `UnitOfWork` (see `app/services/unit_of_work.py`) wires one Repository +
Service graph per database transaction, injected into every handler by
`DatabaseMiddleware`.

**Referral state machine** (`app/services/referral_service.py`):

```
PENDING -> JOINED -> WAITING_8_HOURS -> QUESTIONS_PENDING -> VALID
   |          |
   +----------+---------------------------> LEFT (channel exit, any point before VALID)
                                             INVALID (confirmed fraud / manual admin override)
```

Membership changes are detected **two ways**, deliberately redundant:

1. **Reactive**: a `chat_member` Telegram update (bot must be channel admin
   and subscribe to `allowed_updates=["chat_member", ...]`, already
   configured in `app/main.py`) fires `app/bot/handlers/chat_member.py`
   immediately.
2. **Proactive/defensive fallback**: an APScheduler job
   (`app/scheduler/jobs.py::reevaluate_pending_referrals`) re-verifies
   membership via `getChatMember` on every non-terminal referral, every
   `SCHEDULER_INTERVAL_SECONDS` (default 60s). This guarantees correctness
   even if a `chat_member` update is ever missed or the bot was briefly
   offline -- nothing depends on a single event delivery.

**Reward idempotency** (`app/database/repositories/reward_repository.py`) is
enforced with atomic compare-and-swap `UPDATE ... WHERE status = X` calls,
not application-level locks -- safe even under concurrent claim attempts.

**Campaign settings** (`required_referrals`, `membership_hours`,
`required_activities`, reward copy, channel ID/link, on/off switch) live in
a database row (`campaign_settings` table), editable from the in-bot Admin
Panel -- no source code change or redeploy needed to tune the campaign.
Questions and their options are likewise database rows (`questions`,
`question_options`), seeded with sensible defaults on first run but fully
admin-editable in the schema (extend the Admin Panel's Campaign Settings
section to add question CRUD UI if needed -- the data layer already
supports it).

---

## 2. Project Structure

```
telegram_referral_bot/
|
+-- app/
|   +-- bot/
|   |   +-- handlers/
|   |   |   +-- start.py            /start, referral attribution, welcome/rules screens
|   |   |   +-- membership.py       "check membership" callback
|   |   |   +-- profile.py          5-question trader profile flow + result
|   |   |   +-- activity.py         5-question per-referral activity flow
|   |   |   +-- answers.py          central "ans:" callback dispatcher (see below)
|   |   |   +-- dashboard.py        status, invite link, my referrals, leaderboard, claim
|   |   |   +-- chat_member.py      reactive membership-change handler
|   |   |   +-- rules.py            /rules command
|   |   |   +-- status_command.py   /status command (dashboard shortcut)
|   |   |   +-- admin.py            full admin panel (users, referrals, rewards,
|   |   |                           stats, fraud, campaign settings, broadcast)
|   |   +-- keyboards/              inline keyboard builders (menu, questions, admin)
|   |   +-- middlewares/            DB session, user context/block, throttling, admin auth
|   |   +-- states/                 aiogram FSM state groups
|   |   +-- texts.py                all Persian user-facing copy (rule: Persian-only UI)
|   |   +-- notifications.py        Persian event-notification templates
|   |
|   +-- database/
|   |   +-- models/                 SQLAlchemy 2.x ORM models (10 tables, see below)
|   |   +-- repositories/           pure data-access layer, one per aggregate
|   |   +-- database.py             async engine/session factory, init_models()
|   |
|   +-- services/
|   |   +-- referral_service.py     state machine -- the heart of the campaign logic
|   |   +-- membership_service.py   Telegram getChatMember wrapper
|   |   +-- reward_service.py       idempotent claim orchestration
|   |   +-- fraud_service.py        detection rules (block vs. flag-for-review)
|   |   +-- profile_service.py      deterministic Risk Awareness scoring
|   |   +-- campaign_settings_service.py
|   |   +-- unit_of_work.py         wires repos+services per transaction
|   |
|   +-- scheduler/
|   |   +-- jobs.py                 reevaluate_pending_referrals, run_broadcast
|   |   +-- setup.py                APScheduler wiring
|   |
|   +-- config.py                   Pydantic Settings (.env)
|   +-- main.py                     entrypoint -- long polling, DI wiring, startup seeding
|
+-- tests/                          27 pytest tests (see "Testing" below)
+-- .env.example
+-- requirements.txt
+-- Dockerfile
+-- pytest.ini
+-- README.md (this file)
```

### Why a central `answers.py` router?

Both the 5-question **trader profile** (asked once, per user) and the
5-question **per-referral activity** set use identical
`ans:{question_id}:{option_id}` callback data and identical keyboards.
Rather than two routers both matching `F.data.startswith("ans:")`
ambiguously (only the first-registered one would ever fire), a single
`app/bot/handlers/answers.py` router owns that callback, looks up the
question's `question_set` (`PROFILE` vs `ACTIVITY`), and dispatches to the
matching flow's answer handler. This was caught and fixed during
development via an end-to-end handler test -- see "Testing" below.

### Database schema (10 tables)

| Table | Purpose |
|---|---|
| `users` | Telegram identity, referral code, membership status, counters |
| `referrals` | The state-machine edge (referrer -> referred), all timestamps |
| `questions` / `question_options` | DB-managed question sets (PROFILE, ACTIVITY) |
| `answers` | User's answer to a question (scoped by `referral_id` for ACTIVITY) |
| `trader_profiles` | Computed profile result + Risk Awareness score |
| `rewards` | One row per user, idempotent LOCKED->UNLOCKED->CLAIMED |
| `fraud_flags` | Detected suspicious patterns, OPEN until admin review |
| `admin_logs` | Full audit trail of every admin action |
| `campaign_settings` | Single-row, admin-tunable campaign parameters |

---

## 3. Telegram API Limitations (explicit, per project requirement)

These are real Bot API constraints -- the bot works *around* them rather
than pretending they don't exist:

1. **No "did the user see/vote on a Poll" API.** Telegram does not expose
   this to bots. All required activities are therefore implemented as
   in-bot inline-keyboard questions (`app/bot/handlers/activity.py`), never
   as native Telegram Polls in the channel.

2. **`chat_member` updates require explicit subscription.** Even though the
   bot is a channel admin, Telegram does **not** push membership-change
   events by default -- `allowed_updates` must include `"chat_member"` on
   the polling/webhook call (already done in `app/main.py::run_polling`).
   Without this, membership changes would only ever be caught by the
   scheduler's periodic `getChatMember` polling (still correct, just
   slower -- up to `SCHEDULER_INTERVAL_SECONDS`).

3. **No historical backfill.** `chat_member` events only fire for changes
   *after* the bot starts listening. A user who left the channel before the
   bot was configured won't generate a retroactive event -- but the
   scheduler's periodic `getChatMember` check catches this on its next tick
   regardless, since it re-verifies actual current state, not event history.

4. **`getChatMember` requires bot admin rights on the channel.** If the bot
   is removed as admin, `MembershipService` returns `UNKNOWN` (never
   silently assumes "member") and logs a warning -- see
   `app/services/membership_service.py`.

5. **No device/IP fingerprinting.** Bots cannot see a user's device, IP, or
   browser fingerprint. `FraudService`'s "rapid account creation" heuristic
   (rule requirement) is therefore based on referral **timing patterns**
   only (N+ referrals from the same referrer within a short window) -- this
   is flagged for admin review, never used to auto-block, precisely because
   it's a heuristic and not proof.

6. **Outgoing message rate limits (~30 msg/sec bot-wide).** `run_broadcast`
   (`app/scheduler/jobs.py`) paces sends with a small delay and honors
   `TelegramRetryAfter` if Telegram asks the bot to back off, rather than
   firing all messages in a tight loop.

---

## 4. Setup

### 4.1 Create the bot with BotFather

1. Open a chat with [@BotFather](https://t.me/BotFather) on Telegram.
2. Send `/newbot` and follow the prompts (choose a name and a unique
   `@username` ending in `bot`).
3. BotFather replies with your **BOT_TOKEN** -- a string like
   `123456789:AAExampleTokenxxxxxxxxxxxxxxxxxxxxx`. Copy it.

### 4.2 Create the channel

1. Create a new Telegram **Channel** (not a group) -- this is where invited
   traders must join.
2. Decide if it's public (has a `@username`, e.g. `@my_trading_channel`) or
   private (invite-link only).

### 4.3 Make the bot an admin of the channel

1. In the channel's settings -> **Administrators** -> **Add Admin**.
2. Search for your bot's `@username` and add it.
3. The bot needs at minimum the ability to see members -- the default admin
   permission set is sufficient; no special permissions need to be toggled.

### 4.4 Find your CHANNEL_ID

Easiest method:
1. Forward any message from the channel to
   [@userinfobot](https://t.me/userinfobot) or
   [@RawDataBot](https://t.me/RawDataBot).
2. Look for the `chat.id` field -- it will look like `-1001234567890` for a
   supergroup/channel.

Alternative for **public** channels: you can just use `@your_channel_username`
directly as `CHANNEL_ID` -- Telegram accepts either form for `getChatMember`.

### 4.5 Find your own Telegram user ID (for ADMIN_IDS)

Message [@userinfobot](https://t.me/userinfobot) -- it replies with your
numeric user ID.

### 4.6 Create `.env`

```bash
cp .env.example .env
```

Edit `.env` and fill in:
- `BOT_TOKEN` (from 4.1)
- `ADMIN_IDS` (from 4.5, comma-separated if multiple admins)
- `DEFAULT_CHANNEL_ID` and `DEFAULT_CHANNEL_LINK` (from 4.2/4.4)

These channel defaults are only used to **bootstrap** the `campaign_settings`
database row on first run -- after that, change them anytime from the in-bot
Admin Panel -> Campaign Settings, with no restart needed.

### 4.7 Install dependencies

```bash
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 4.8 Run locally

```bash
python -m app.main
```

On first run this will:
- Create `./data/bot.db` (SQLite) and all tables (non-destructively --
  re-running this is always safe and never drops data).
- Seed the default 5 profile questions + 5 activity questions if the
  `questions` table is empty.
- Start long polling (no inbound port, no domain, no HTTPS needed).

Send `/start` to your bot on Telegram to try it.

### 4.9 Run in the cloud

Any host that can run a long-lived Python process with outbound internet
access works -- no inbound port, domain, or TLS certificate required, since
this MVP uses long polling. Examples: a small VPS, a free-tier container
host, Railway, Fly.io, PythonAnywhere (paid tier for always-on), or a
Docker host:

```bash
docker build -t referral-bot .
docker run -d --name referral-bot \
  --env-file .env \
  -v referral_bot_data:/app/data \
  referral-bot
```

The `-v referral_bot_data:/app/data` volume is what makes the SQLite
database (and logs) persist across container restarts/redeploys -- **do not
skip this**, or every redeploy would start the campaign from zero.

---

## 5. Database Management

### 5.1 How initialization works

`app/database/database.py::init_models()` runs `Base.metadata.create_all`
on every startup. This is **idempotent and non-destructive**: it creates
tables that don't exist yet and never touches or drops existing ones. This
satisfies the "never lose data on restart" requirement without needing a
migrations tool for the SQLite MVP phase.

### 5.2 Backup

SQLite's entire database is one file. To back it up safely while the bot is
running (SQLite is in WAL mode, so this is safe):

```bash
sqlite3 ./data/bot.db ".backup './data/bot_backup_$(date +%Y%m%d_%H%M%S).db'"
```

Automate this with a cron job / scheduled task pointing at the same
command. Store backups off the host (S3, another server, etc.) for real
durability.

### 5.3 Migrating to PostgreSQL later

The entire data layer is written against SQLAlchemy's **async** API with no
SQLite-specific logic outside of `app/database/database.py`'s WAL-mode
pragma setup (which is skipped automatically for non-SQLite URLs). To
migrate:

1. Provision a PostgreSQL database.
2. `pip install asyncpg alembic`
3. Change `DATABASE_URL` in `.env` to:
   ```
   postgresql+asyncpg://user:password@host:5432/dbname
   ```
4. Set up Alembic (`alembic init migrations`) pointed at
   `app.database.models.Base.metadata`, generate an initial migration
   (`alembic revision --autogenerate -m "initial"`), and run
   `alembic upgrade head` instead of relying on `init_models()`'s
   `create_all` (which is fine for SQLite MVP but Alembic is the right tool
   once you need real schema migrations).
5. Migrate data: for a small campaign, `pgloader` can migrate directly from
   the SQLite file to PostgreSQL. For anything larger, write a one-off
   script using the same repositories to read from SQLite and write to
   PostgreSQL.

**No application code (models, repositories, services, handlers) needs to
change.** This was a deliberate, tested architectural constraint from the
start (see `app/database/database.py`'s docstring).

---

## 6. Testing

```bash
pytest
```

27 tests covering every area required:

| File | Covers |
|---|---|
| `test_referral_attribution.py` | Attribution, self-referral rejection, invalid code handling, immutability after first registration, no duplicate referral rows, referral code uniqueness |
| `test_eligibility.py` | 8-hour `eligible_at` calculation, admin-configurable `membership_hours`, evaluate_referral before/after the window, membership loss -> LEFT |
| `test_valid_referral_and_reward.py` | All-conditions-required for VALID, reward unlocks exactly at the 5th valid referral, stays locked below threshold, counter self-heals from source of truth |
| `test_reward_idempotency.py` | Claim fails while locked, succeeds exactly once when unlocked, second claim is a no-op, repeated claims raise a fraud flag, simulated concurrent claims only let one through |
| `test_admin_authorization.py` | Admin middleware allows configured admins, rejects + notifies non-admins (message and callback), rejects missing user, `ADMIN_IDS` parsing, admin router actually has the middleware attached |

Tests use an isolated in-memory SQLite database per test (see
`tests/conftest.py`) -- no real Telegram network calls, no shared state
between tests.

During development, a full end-to-end simulation was also run driving the
actual handler functions (`handle_start`, `handle_start_campaign`,
`handle_answer`, `handle_dashboard`, `handle_claim_reward`, ...) against
faked Telegram objects, exercising the complete user journey from `/start`
through 5 validated referrals to an idempotent reward claim. This caught
the `answers.py` routing-ambiguity issue and a `Reward` row
compare-and-swap bug (see inline comments in `referral_service.py` and
`reward_repository.py` for details) before they could reach production.

---

## 7. Extensibility (rule: architecture-ready, not built yet)

The following are explicitly **not implemented** in this version but the
architecture leaves room for them without a rewrite:

- **Telegram Mini App**: handlers currently render pure inline-keyboard
  text screens; a Mini App could be added as an alternative presentation
  layer calling into the same `services/` layer.
- **Payments/Subscriptions**: `RewardService`'s compare-and-swap pattern
  generalizes directly to a paid-tier unlock flow.
- **Multiple campaigns**: `CampaignSettings.key` is already a primary key
  (currently pinned to `"default"`) -- extending to multiple campaigns means
  turning this into a real multi-row table keyed by campaign slug, and
  adding a `campaign_id` foreign key to `User`/`Referral`, not a schema
  rewrite.
- **Referral tiers, multiple rewards**: `Reward` is currently one-per-user;
  a tier system would add a `RewardTier` table and change `RewardService`
  to evaluate against tier thresholds instead of a single
  `required_referrals` value.
- **Analytics dashboard**: all raw data needed already exists in normalized
  form (`admin_logs`, `referrals` with full timestamps, `fraud_flags`) --
  an analytics view would be a read-only reporting layer on top.
- **AI Trader Profile / Risk Coach Pro integration**: `ProfileService`
  already isolates "compute a profile from answers" behind a single method
  (`compute_and_save`) -- swapping the deterministic scorer for an
  LLM-assisted one is a contained change.

---

## 8. Security Notes

- `BOT_TOKEN` and all secrets live only in `.env` (never committed -- see
  `.gitignore`).
- Admin panel access is gated by `AdminAuthMiddleware`, checking
  `ADMIN_IDS` from `.env` -- no handler re-implements this check.
- All state-changing logic runs server-side against the database; no
  business rule trusts client-supplied timestamps or FSM state alone.
- SQL injection is not applicable in the traditional sense since all
  queries go through SQLAlchemy's parameterized query builder -- no raw SQL
  string interpolation exists anywhere in the codebase.
- Rate limiting: `ThrottlingMiddleware` throttles per-user update frequency;
  `run_broadcast` paces outgoing messages to respect Telegram's global rate
  limit.
- The bot never asks for passwords, broker logins, trading account
  credentials, or private keys -- see `/rules` in-bot and
  `app/bot/texts.py::rules_text()`.

---

## 9. Known Behavioral Notes

- If a referral has already reached `VALID` and the referred user later
  leaves the channel, the referral is **not** retroactively invalidated --
  `ReferralService` treats `VALID` as a terminal state, since reversing an
  already-counted, already-possibly-rewarded referral could unfairly strip
  a referrer of a reward they'd legitimately earned. Only an admin's
  explicit manual override (Admin Panel -> Referrals -> Force INVALID) can
  change a `VALID` referral's status after the fact.
- Fraud flags are informational by default and never silently invalidate a
  referral -- only two flag types (`DUPLICATE_TELEGRAM_ID`,
  `MULTIPLE_REWARD_CLAIM_ATTEMPT`) hold a referral at `QUESTIONS_PENDING`
  pending admin review; everything else surfaces in the Admin Panel's Fraud
  section for a human decision (see `fraud_service.py::BLOCKING_FLAG_TYPES`).
