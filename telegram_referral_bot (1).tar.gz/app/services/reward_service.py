"""
RewardService.

Thin orchestration layer over RewardRepository's atomic compare-and-swap
operations, which are what actually guarantee idempotency (rule #15). This
service adds fraud-flagging on repeated-claim attempts and campaign-setting
lookups for the reward's display copy.
"""
from __future__ import annotations

from app.database.models import Reward, RewardStatus, User
from app.database.repositories import CampaignSettingsRepository, RewardRepository
from app.services.fraud_service import FraudService


class RewardService:
    def __init__(
        self,
        reward_repo: RewardRepository,
        campaign_repo: CampaignSettingsRepository,
        fraud_service: FraudService,
    ) -> None:
        self.reward_repo = reward_repo
        self.campaign_repo = campaign_repo
        self.fraud_service = fraud_service

    async def get_or_init_reward(self, user: User) -> Reward:
        return await self.reward_repo.get_or_create(user.id)

    async def claim(self, user: User) -> tuple[bool, Reward]:
        """
        Attempts to claim. Returns (success, reward).
        success=False means either it was never unlocked, or it was already
        claimed before (idempotent no-op) — the caller distinguishes via
        reward.status for messaging purposes.
        """
        reward = await self.reward_repo.get_or_create(user.id)

        if reward.status == RewardStatus.CLAIMED:
            await self.fraud_service.flag_multiple_claim_attempt(user)
            return False, reward

        if reward.status == RewardStatus.LOCKED:
            return False, reward

        success = await self.reward_repo.try_claim(user.id)
        # Refresh local object state to reflect the DB after the CAS update.
        refreshed = await self.reward_repo.get_by_user_id(user.id)
        return success, refreshed or reward
