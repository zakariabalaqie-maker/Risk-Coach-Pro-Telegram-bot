"""Thin service wrapper over CampaignSettingsRepository (rule #17)."""
from __future__ import annotations

from app.database.models import CampaignSettings
from app.database.repositories import CampaignSettingsRepository


class CampaignSettingsService:
    def __init__(self, repo: CampaignSettingsRepository) -> None:
        self.repo = repo

    async def get(self) -> CampaignSettings:
        return await self.repo.get()

    async def update(self, **kwargs) -> CampaignSettings:
        return await self.repo.update(**kwargs)
