"""
UnitOfWork.

A single place that wires all repositories and services against one
AsyncSession, so handlers/scheduler jobs don't have to hand-assemble the
dependency graph every time. One UnitOfWork = one transaction (see
`app.database.database.session_scope`).

Usage:

    async with session_scope() as session:
        uow = UnitOfWork(session)
        await uow.referral_service.attribute_referral(...)
    # commits automatically on clean exit
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.repositories import (
    AdminLogRepository,
    CampaignSettingsRepository,
    FraudRepository,
    ProfileRepository,
    QuestionRepository,
    ReferralRepository,
    RewardRepository,
    UserRepository,
)
from app.services.campaign_settings_service import CampaignSettingsService
from app.services.fraud_service import FraudService
from app.services.profile_service import ProfileService
from app.services.referral_service import ReferralService
from app.services.reward_service import RewardService


class UnitOfWork:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

        # Repositories
        self.user_repo = UserRepository(session)
        self.referral_repo = ReferralRepository(session)
        self.question_repo = QuestionRepository(session)
        self.profile_repo = ProfileRepository(session)
        self.reward_repo = RewardRepository(session)
        self.fraud_repo = FraudRepository(session)
        self.admin_log_repo = AdminLogRepository(session)
        self.campaign_repo = CampaignSettingsRepository(session)

        # Services
        self.fraud_service = FraudService(self.user_repo, self.fraud_repo)
        self.profile_service = ProfileService(self.question_repo, self.profile_repo)
        self.campaign_settings_service = CampaignSettingsService(self.campaign_repo)
        self.referral_service = ReferralService(
            user_repo=self.user_repo,
            referral_repo=self.referral_repo,
            question_repo=self.question_repo,
            reward_repo=self.reward_repo,
            campaign_repo=self.campaign_repo,
            fraud_service=self.fraud_service,
        )
        self.reward_service = RewardService(self.reward_repo, self.campaign_repo, self.fraud_service)
