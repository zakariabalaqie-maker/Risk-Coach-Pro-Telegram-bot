"""
FraudService.

Implements rule #19: detect suspicious patterns without auto-condemning
users when evidence is inconclusive. Every check here either:
  (a) blocks an action outright because it's unambiguous (e.g. self-referral,
      an already-referred user, a duplicate referral row) — these are hard
      business-rule violations, not "fraud probability", so they raise
      FraudViolation and the caller rejects the action synchronously; or
  (b) raises a FraudFlag for admin review because the signal is merely
      suspicious (e.g. rapid account creation, repeated device/IP-adjacent
      patterns as far as Telegram exposes them) — these NEVER block a
      referral from progressing on their own; only a CONFIRMED review or an
      admin's manual INVALID marks a referral invalid because of them.

BLOCKING_FLAG_TYPES defines which flag types, if OPEN or CONFIRMED, DO
withhold VALID status until resolved — kept intentionally small and limited
to signals that are close to certain.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Optional

from app.database.models import FraudFlagType, User, as_aware_utc, utcnow
from app.database.repositories import FraudRepository, UserRepository

# Flag types serious enough to withhold VALID status pending admin review.
# Everything else is informational-only and never blocks the state machine.
BLOCKING_FLAG_TYPES = {
    FraudFlagType.DUPLICATE_TELEGRAM_ID,
    FraudFlagType.MULTIPLE_REWARD_CLAIM_ATTEMPT,
}

# A burst of N+ new accounts referred by the same user within this window
# is flagged as suspicious (not blocked) for admin review.
RAPID_CREATION_WINDOW = timedelta(minutes=10)
RAPID_CREATION_THRESHOLD = 4


class FraudViolation(Exception):
    """Raised for hard, unambiguous rule violations that must reject the action immediately."""


class FraudService:
    def __init__(self, user_repo: UserRepository, fraud_repo: FraudRepository) -> None:
        self.user_repo = user_repo
        self.fraud_repo = fraud_repo

    async def validate_referral_attribution(
        self, *, new_user_telegram_id: int, referrer: Optional[User], is_new_user: bool
    ) -> None:
        """
        Called at /start time, before attributing a referral. Raises
        FraudViolation for anything that must hard-block attribution;
        silently no-ops for anything acceptable.
        """
        if referrer is None:
            return

        if referrer.telegram_id == new_user_telegram_id:
            await self.fraud_repo.create_flag(
                user_id=referrer.id,
                flag_type=FraudFlagType.SELF_REFERRAL_ATTEMPT,
                detail=f"telegram_id={new_user_telegram_id} tried to use their own referral code",
            )
            raise FraudViolation("self_referral")

        if not is_new_user:
            # Rule #6: "User موجودی که قبلاً وارد سیستم شده، Referral جدید محسوب نشود"
            await self.fraud_repo.create_flag(
                user_id=referrer.id,
                flag_type=FraudFlagType.EXISTING_USER_ATTRIBUTION,
                detail=f"telegram_id={new_user_telegram_id} already existed; late referral code ignored",
            )
            raise FraudViolation("existing_user_attribution")

    async def check_rapid_account_creation(self, referrer: User) -> None:
        """
        Heuristic-only check (rule #19's 'Rapid account creation patterns').
        Flags for review; NEVER blocks. Telegram doesn't expose device/IP
        info to bots, so this is the practical limit of what's detectable —
        see README 'Telegram API Limitations' section.
        """
        from app.database.repositories import ReferralRepository  # local import: avoid cycle

        referral_repo = ReferralRepository(self.user_repo.session)
        referrals = await referral_repo.list_by_referrer(referrer.id)
        recent_cutoff = utcnow() - RAPID_CREATION_WINDOW
        recent_count = sum(1 for r in referrals if as_aware_utc(r.created_at) >= recent_cutoff)
        if recent_count >= RAPID_CREATION_THRESHOLD:
            await self.fraud_repo.create_flag(
                user_id=referrer.id,
                flag_type=FraudFlagType.RAPID_ACCOUNT_CREATION,
                detail=(
                    f"{recent_count} referrals created within "
                    f"{RAPID_CREATION_WINDOW.total_seconds() / 60:.0f} minutes"
                ),
            )

    async def has_blocking_open_flags(self, user_id: int) -> bool:
        flags = await self.fraud_repo.list_open_for_user(user_id)
        return any(f.flag_type in BLOCKING_FLAG_TYPES for f in flags)

    async def flag_multiple_claim_attempt(self, user: User) -> None:
        await self.fraud_repo.create_flag(
            user_id=user.id,
            flag_type=FraudFlagType.MULTIPLE_REWARD_CLAIM_ATTEMPT,
            detail="Reward claim attempted after reward was already CLAIMED",
        )

    async def flag_manual(self, *, user_id: int, admin_id: int, detail: str) -> None:
        await self.fraud_repo.create_flag(
            user_id=user_id,
            flag_type=FraudFlagType.MANUAL_ADMIN_FLAG,
            detail=f"By admin {admin_id}: {detail}",
        )
