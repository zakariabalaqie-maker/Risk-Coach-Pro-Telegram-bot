"""
MembershipService.

Wraps Telegram's `getChatMember` (rule #7). This is the ONLY reliable,
pull-based way for a bot to check whether a specific user is currently a
member of a channel it administers.

Known Telegram API limitation (documented explicitly per project
instructions): there is no bot API method to ask "has this user viewed a
Poll in the channel" or "did this user vote" — rule #25 already forbids
relying on that, and this service does not attempt it.

For membership CHANGE events (join/leave), Telegram *does* push
`chat_member` updates to bots that are channel admins, when the bot
subscribes via `allowed_updates=["chat_member", ...]` on the polling/webhook
call. This service is used both:
  1. reactively, from the ChatMemberUpdated handler (fast path), and
  2. proactively/defensively, polled by the scheduler as a fallback in case
     an update was missed (rule #12's explicit requirement to re-verify
     server-side before finalizing eligibility).
"""
from __future__ import annotations

import logging

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest, TelegramForbiddenError

from app.database.models import MembershipStatus

logger = logging.getLogger(__name__)

# Telegram ChatMember statuses that count as "still a member" for our purposes.
_MEMBER_STATUSES = {"member", "administrator", "creator"}
_LEFT_STATUSES = {"left"}
_KICKED_STATUSES = {"kicked"}


class MembershipService:
    def __init__(self, bot: Bot, channel_id: str) -> None:
        self.bot = bot
        self.channel_id = channel_id

    async def check_membership(self, telegram_user_id: int) -> MembershipStatus:
        """
        Calls Telegram's getChatMember. Requires the bot to be an admin of
        `channel_id` — if it isn't, Telegram returns a 400/403 error, which
        we surface as UNKNOWN (never silently treat as "member").
        """
        if not self.channel_id:
            logger.warning("MembershipService.check_membership called with empty channel_id")
            return MembershipStatus.UNKNOWN

        try:
            member = await self.bot.get_chat_member(chat_id=self.channel_id, user_id=telegram_user_id)
        except TelegramForbiddenError:
            # Bot was removed from the channel, or user blocked the bot in a way
            # that affects visibility — cannot determine, do not guess.
            logger.warning("Forbidden checking membership for %s in %s", telegram_user_id, self.channel_id)
            return MembershipStatus.UNKNOWN
        except TelegramBadRequest as exc:
            # e.g. "user not found" -> never joined; "chat not found" -> misconfigured channel_id
            logger.info("BadRequest checking membership for %s: %s", telegram_user_id, exc)
            if "user not found" in str(exc).lower():
                return MembershipStatus.UNKNOWN
            return MembershipStatus.UNKNOWN
        except TelegramAPIError as exc:
            logger.error("Telegram API error checking membership: %s", exc)
            return MembershipStatus.UNKNOWN

        status = member.status
        if status in _MEMBER_STATUSES:
            return MembershipStatus.MEMBER
        if status in _KICKED_STATUSES:
            return MembershipStatus.KICKED
        if status in _LEFT_STATUSES:
            return MembershipStatus.LEFT
        return MembershipStatus.UNKNOWN

    async def is_bot_admin_of_channel(self) -> bool:
        """Sanity check used at startup / in the admin panel diagnostics."""
        if not self.channel_id:
            return False
        try:
            me = await self.bot.get_me()
            member = await self.bot.get_chat_member(chat_id=self.channel_id, user_id=me.id)
            return member.status in ("administrator", "creator")
        except TelegramAPIError as exc:
            logger.error("Could not verify bot admin status on channel: %s", exc)
            return False
