"""
ReferralService.

Owns the Referral state machine (rule #11):

    PENDING -> JOINED -> WAITING_8_HOURS -> QUESTIONS_PENDING -> VALID
                  \\-> LEFT (at any point before VALID, if membership lapses)
    (any state) -> INVALID (fraud confirmed or manual admin action)

All transitions happen here, and only here — handlers and the scheduler
call into this service rather than mutating Referral rows directly, so the
state machine has exactly one implementation.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional

from app.database.models import MembershipStatus, Referral, ReferralStatus, User, as_aware_utc, utcnow
from app.database.repositories import (
    CampaignSettingsRepository,
    QuestionRepository,
    ReferralRepository,
    RewardRepository,
    UserRepository,
)
from app.services.fraud_service import FraudService, FraudViolation

logger = logging.getLogger(__name__)


@dataclass
class AttributionResult:
    referral: Optional[Referral]
    rejected_reason: Optional[str] = None  # "self_referral" | "existing_user_attribution" | "invalid_code" | None


class ReferralService:
    def __init__(
        self,
        user_repo: UserRepository,
        referral_repo: ReferralRepository,
        question_repo: QuestionRepository,
        reward_repo: RewardRepository,
        campaign_repo: CampaignSettingsRepository,
        fraud_service: FraudService,
    ) -> None:
        self.user_repo = user_repo
        self.referral_repo = referral_repo
        self.question_repo = question_repo
        self.reward_repo = reward_repo
        self.campaign_repo = campaign_repo
        self.fraud_service = fraud_service

    # ------------------------------------------------------------------
    # Attribution (rule #6)
    # ------------------------------------------------------------------

    async def attribute_referral(
        self, *, new_user: User, referral_code: Optional[str], is_new_user: bool
    ) -> AttributionResult:
        """
        Called once, at first /start. Idempotent: if the user already has a
        referrer (referred_by_id is set), this is a no-op — referral
        attribution is immutable after first registration (rule #6).
        """
        if new_user.referred_by_id is not None:
            # Already attributed previously; never re-attribute.
            existing = await self.referral_repo.get_by_referred_user_id(new_user.id)
            return AttributionResult(referral=existing, rejected_reason=None)

        if not referral_code:
            return AttributionResult(referral=None, rejected_reason=None)

        referrer = await self.user_repo.get_by_referral_code(referral_code)
        if referrer is None:
            return AttributionResult(referral=None, rejected_reason="invalid_code")

        try:
            await self.fraud_service.validate_referral_attribution(
                new_user_telegram_id=new_user.telegram_id,
                referrer=referrer,
                is_new_user=is_new_user,
            )
        except FraudViolation as exc:
            return AttributionResult(referral=None, rejected_reason=str(exc))

        # Duplicate-referral guard: unique constraint on referred_user_id
        # also enforces this at the DB layer; this check gives a clean
        # in-app response instead of surfacing an IntegrityError.
        existing = await self.referral_repo.get_by_referred_user_id(new_user.id)
        if existing is not None:
            return AttributionResult(referral=existing, rejected_reason=None)

        new_user.referred_by_id = referrer.id
        referral = await self.referral_repo.create(referrer_id=referrer.id, referred_user_id=new_user.id)

        await self.fraud_service.check_rapid_account_creation(referrer)

        return AttributionResult(referral=referral)

    # ------------------------------------------------------------------
    # Membership-driven transitions (rules #7, #12)
    # ------------------------------------------------------------------

    async def on_membership_confirmed(self, user: User) -> None:
        """
        Called when a user is confirmed MEMBER of the channel — either the
        referred user themself (advances their own inbound Referral row) or
        just generally (no-op if they have no inbound referral, e.g. the
        campaign's very first user).
        """
        referral = await self.referral_repo.get_by_referred_user_id(user.id)
        if referral is None:
            return  # organic user, nothing to advance
        if referral.status not in (ReferralStatus.PENDING, ReferralStatus.LEFT):
            return  # already past this point, or terminal

        settings = await self.campaign_repo.get()
        now = utcnow()
        referral.joined_at = referral.joined_at or now
        referral.eligible_at = referral.joined_at + timedelta(hours=settings.membership_hours)
        referral.status = ReferralStatus.JOINED

    async def on_membership_lost(self, user: User) -> None:
        """Called when a user is confirmed to have left/been kicked from the channel."""
        referral = await self.referral_repo.get_by_referred_user_id(user.id)
        if referral is None:
            return
        if referral.status in (ReferralStatus.VALID, ReferralStatus.INVALID, ReferralStatus.LEFT):
            return  # terminal states are not reopened by a later leave event
        referral.status = ReferralStatus.LEFT
        referral.left_at = utcnow()

    # ------------------------------------------------------------------
    # Activities (rule #13)
    # ------------------------------------------------------------------

    async def record_activity_progress(self, referral: Referral, *, completed_count: int) -> None:
        settings = await self.campaign_repo.get()
        referral.activities_progress = completed_count
        if completed_count >= settings.required_activities and not referral.activities_completed:
            referral.activities_completed = True
            referral.questions_completed_at = utcnow()
            if referral.status == ReferralStatus.WAITING_8_HOURS:
                referral.status = ReferralStatus.QUESTIONS_PENDING

    # ------------------------------------------------------------------
    # Eligibility evaluation (rules #12, #14) — called by scheduler AND
    # opportunistically after activity completion, so validation happens
    # as soon as both conditions (8h elapsed + activities done) are true,
    # regardless of which one completes second.
    # ------------------------------------------------------------------

    async def evaluate_referral(self, referral: Referral, *, membership_service) -> ReferralStatus:
        """
        Re-checks membership server-side (never trusting a stale flag) and
        advances/validates the referral if all rule #14 conditions hold.
        Returns the resulting status.
        """
        if referral.status in (ReferralStatus.VALID, ReferralStatus.INVALID, ReferralStatus.LEFT):
            return referral.status

        referred_user = referral.referred_user
        now = utcnow()

        current_membership = await membership_service.check_membership(referred_user.telegram_id)
        await self.user_repo.set_membership_status(referred_user, current_membership, at=now)

        if current_membership in (MembershipStatus.LEFT, MembershipStatus.KICKED):
            referral.status = ReferralStatus.LEFT
            referral.left_at = now
            return referral.status

        if current_membership != MembershipStatus.MEMBER:
            return referral.status  # UNKNOWN: leave as-is, will be re-checked next tick

        eight_hours_done = referral.eligible_at is not None and now >= as_aware_utc(referral.eligible_at)

        if not eight_hours_done:
            if referral.status == ReferralStatus.JOINED:
                referral.status = ReferralStatus.WAITING_8_HOURS
            return referral.status

        # 8h elapsed and still a member -> advance past the waiting stage.
        if referral.status in (ReferralStatus.JOINED, ReferralStatus.WAITING_8_HOURS):
            referral.status = ReferralStatus.QUESTIONS_PENDING

        if not referral.activities_completed:
            return referral.status  # still need activities before VALID

        fraud_blocked = await self.fraud_service.has_blocking_open_flags(referred_user.id)
        referral.fraud_status_clean = not fraud_blocked
        if fraud_blocked:
            return referral.status  # held at QUESTIONS_PENDING pending admin review

        await self._mark_valid(referral)
        return referral.status

    async def _mark_valid(self, referral: Referral) -> None:
        referral.status = ReferralStatus.VALID
        referral.validated_at = utcnow()

        referrer = await self.user_repo.get_by_id(referral.referrer_id)
        if referrer is None:
            logger.error("Referral %s validated but referrer %s missing", referral.id, referral.referrer_id)
            return

        # Flush so the VALID status just set above is visible to the COUNT
        # query below (autoflush covers most cases, but we make it explicit
        # since correctness here is critical — an undercount would silently
        # withhold reward unlocking).
        await self.referral_repo.session.flush()

        # Recompute the counter from the source of truth (VALID referral
        # rows) rather than a blind increment, so it self-heals if it ever
        # drifts (e.g. after a manual admin override).
        valid_count = await self.referral_repo.count_by_referrer_and_status(
            referrer.id, [ReferralStatus.VALID]
        )
        referrer.valid_referrals_count = valid_count

        settings = await self.campaign_repo.get()
        if valid_count >= settings.required_referrals:
            # The reward row must exist before try_unlock's compare-and-swap
            # UPDATE can match it — get_or_create is idempotent, so calling
            # it here every time a referrer crosses the threshold is safe.
            await self.reward_repo.get_or_create(referrer.id)
            await self.reward_repo.try_unlock(
                referrer.id, title=settings.reward_title, description=settings.reward_description
            )

    # ------------------------------------------------------------------
    # Admin manual override (rule #18)
    # ------------------------------------------------------------------

    async def admin_set_status(self, referral: Referral, *, status: ReferralStatus, admin_user_id: int) -> None:
        referral.manually_overridden = True
        referral.overridden_by_admin_id = admin_user_id
        if status == ReferralStatus.VALID:
            await self._mark_valid(referral)
        elif status == ReferralStatus.INVALID:
            referral.status = ReferralStatus.INVALID
            referral.invalidated_at = utcnow()
            referral.invalidated_reason = "manual_admin_override"
            await self._recompute_referrer_count(referral.referrer_id)
        else:
            referral.status = status

    async def _recompute_referrer_count(self, referrer_id: int) -> None:
        referrer = await self.user_repo.get_by_id(referrer_id)
        if referrer is None:
            return
        valid_count = await self.referral_repo.count_by_referrer_and_status(
            referrer_id, [ReferralStatus.VALID]
        )
        referrer.valid_referrals_count = valid_count

    # ------------------------------------------------------------------
    # Read helpers for dashboard (rule #10)
    # ------------------------------------------------------------------

    async def get_referral_breakdown(self, referrer_id: int) -> dict[str, int]:
        valid = await self.referral_repo.count_by_referrer_and_status(referrer_id, [ReferralStatus.VALID])
        waiting = await self.referral_repo.count_by_referrer_and_status(
            referrer_id,
            [
                ReferralStatus.PENDING,
                ReferralStatus.JOINED,
                ReferralStatus.WAITING_8_HOURS,
                ReferralStatus.QUESTIONS_PENDING,
            ],
        )
        invalid = await self.referral_repo.count_by_referrer_and_status(
            referrer_id, [ReferralStatus.INVALID, ReferralStatus.LEFT]
        )
        return {"valid": valid, "waiting": waiting, "invalid": invalid}
