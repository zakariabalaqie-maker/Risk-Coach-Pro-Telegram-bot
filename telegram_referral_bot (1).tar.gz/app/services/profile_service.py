"""
ProfileService.

Computes the Trader Profile result (rule #9) deterministically from stored
Answer rows. "Deterministic" here means: same answers always produce the
same score — no randomness, no LLM call, pure arithmetic over the
`score_weight` values that admins configure per QuestionOption (rule #17).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.database.models import QuestionSet
from app.database.repositories import ProfileRepository, QuestionRepository


@dataclass
class ProfileResult:
    experience_label: str
    primary_market_label: str
    main_challenge_label: str
    typical_risk_label: str
    preferred_tool_label: str
    risk_awareness_score: int


# Maps dimension_key -> which ProfileResult field it fills.
_DIMENSION_TO_FIELD = {
    "experience": "experience_label",
    "market": "primary_market_label",
    "challenge": "main_challenge_label",
    "risk_pct": "typical_risk_label",
    "tool_pref": "preferred_tool_label",
}

# Which dimensions feed into the numeric Risk Awareness score, and their
# relative weight in the final 0-100 figure. Must sum to 1.0.
_SCORE_DIMENSION_WEIGHTS = {
    "experience": 0.25,
    "risk_pct": 0.45,
    "tool_pref": 0.30,
}


class ProfileService:
    def __init__(self, question_repo: QuestionRepository, profile_repo: ProfileRepository) -> None:
        self.question_repo = question_repo
        self.profile_repo = profile_repo

    async def compute_and_save(self, user_id: int) -> ProfileResult:
        answers = await self.question_repo.list_answers_for_user(
            user_id=user_id, question_set=QuestionSet.PROFILE
        )

        labels: dict[str, str] = {
            "experience_label": "نامشخص",
            "primary_market_label": "نامشخص",
            "main_challenge_label": "نامشخص",
            "typical_risk_label": "نامشخص",
            "preferred_tool_label": "نامشخص",
        }
        weight_by_dimension: dict[str, int] = {}

        for answer in answers:
            dimension_key = answer.question.dimension_key
            if not dimension_key:
                continue
            field = _DIMENSION_TO_FIELD.get(dimension_key)
            if field:
                labels[field] = answer.option.label
            weight_by_dimension[dimension_key] = answer.option.score_weight

        score = self._compute_score(weight_by_dimension)

        profile = await self.profile_repo.upsert(
            user_id=user_id,
            experience_label=labels["experience_label"],
            primary_market_label=labels["primary_market_label"],
            main_challenge_label=labels["main_challenge_label"],
            typical_risk_label=labels["typical_risk_label"],
            preferred_tool_label=labels["preferred_tool_label"],
            risk_awareness_score=score,
        )

        return ProfileResult(
            experience_label=profile.experience_label,
            primary_market_label=profile.primary_market_label,
            main_challenge_label=profile.main_challenge_label,
            typical_risk_label=profile.typical_risk_label,
            preferred_tool_label=profile.preferred_tool_label,
            risk_awareness_score=profile.risk_awareness_score,
        )

    @staticmethod
    def _compute_score(weight_by_dimension: dict[str, int]) -> int:
        """
        Deterministic weighted average, rounded to nearest int, clamped to
        [0, 100]. Missing dimensions are simply excluded and the remaining
        weights are renormalized, so a partially-answered set (shouldn't
        happen in practice since all 5 are mandatory) never crashes.
        """
        total_weight = 0.0
        weighted_sum = 0.0
        for dimension, factor in _SCORE_DIMENSION_WEIGHTS.items():
            if dimension in weight_by_dimension:
                weighted_sum += weight_by_dimension[dimension] * factor
                total_weight += factor

        if total_weight == 0:
            return 0

        raw_score = weighted_sum / total_weight
        return max(0, min(100, round(raw_score)))

    async def get_existing(self, user_id: int) -> Optional[ProfileResult]:
        profile = await self.profile_repo.get_by_user_id(user_id)
        if profile is None:
            return None
        return ProfileResult(
            experience_label=profile.experience_label or "نامشخص",
            primary_market_label=profile.primary_market_label or "نامشخص",
            main_challenge_label=profile.main_challenge_label or "نامشخص",
            typical_risk_label=profile.typical_risk_label or "نامشخص",
            preferred_tool_label=profile.preferred_tool_label or "نامشخص",
            risk_awareness_score=profile.risk_awareness_score,
        )
