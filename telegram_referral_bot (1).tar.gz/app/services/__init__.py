"""Service layer registry."""
from app.services.campaign_settings_service import CampaignSettingsService
from app.services.fraud_service import FraudService, FraudViolation
from app.services.membership_service import MembershipService
from app.services.profile_service import ProfileResult, ProfileService
from app.services.referral_service import AttributionResult, ReferralService
from app.services.reward_service import RewardService
from app.services.unit_of_work import UnitOfWork

__all__ = [
    "UnitOfWork",
    "ReferralService",
    "AttributionResult",
    "MembershipService",
    "RewardService",
    "FraudService",
    "FraudViolation",
    "ProfileService",
    "ProfileResult",
    "CampaignSettingsService",
]
