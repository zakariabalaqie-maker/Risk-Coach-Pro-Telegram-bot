"""
Start handler.

Covers rule #5 (bot flow /start) and rule #6 (referral attribution).
Attribution happens exactly once here, at first contact — see
ReferralService.attribute_referral for the immutability/fraud guards.
"""
from __future__ import annotations

import logging
from typing import Optional

from aiogram import Bot, F, Router
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import CallbackQuery, Message

from app.bot import texts
from app.bot.keyboards.menu import (
    CB_BACK_TO_MENU,
    CB_SHOW_RULES,
    CB_START_CAMPAIGN,
    join_channel_keyboard,
    welcome_keyboard,
)
from app.bot.middlewares.throttling import ThrottlingMiddleware
from app.database.models import MembershipStatus, User
from app.services import MembershipService, UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="start")
router.message.middleware(ThrottlingMiddleware())


async def _get_or_create_user(uow: UnitOfWork, tg_user) -> tuple[User, bool]:
    """Returns (user, is_new)."""
    existing = await uow.user_repo.get_by_telegram_id(tg_user.id)
    if existing is not None:
        return existing, False
    created = await uow.user_repo.create_user(
        telegram_id=tg_user.id,
        username=tg_user.username,
        first_name=tg_user.first_name,
        last_name=tg_user.last_name,
        language_code=tg_user.language_code,
    )
    return created, True


@router.message(CommandStart())
async def handle_start(message: Message, command: CommandObject, uow: UnitOfWork) -> None:
    tg_user = message.from_user
    if tg_user is None:
        return

    user, is_new = await _get_or_create_user(uow, tg_user)

    referral_code: Optional[str] = command.args.strip() if command.args else None
    attribution_notice: Optional[str] = None

    if referral_code:
        result = await uow.referral_service.attribute_referral(
            new_user=user, referral_code=referral_code, is_new_user=is_new
        )
        if result.rejected_reason == "self_referral":
            attribution_notice = texts.self_referral_notice()
        elif result.rejected_reason == "invalid_code":
            attribution_notice = texts.invalid_referral_notice()
        # "existing_user_attribution" is silently ignored per rule #6 —
        # no need to surface it as an error to a returning user.

    user.has_started_bot = True

    if attribution_notice:
        await message.answer(attribution_notice)

    if not is_new and user.has_completed_profile:
        await message.answer(
            texts.already_started_text(), reply_markup=welcome_keyboard(show_dashboard=True)
        )
        return

    await message.answer(texts.welcome_text(), reply_markup=welcome_keyboard())


@router.callback_query(F.data == CB_START_CAMPAIGN)
async def handle_start_campaign(callback: CallbackQuery, uow: UnitOfWork, bot: Bot) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    settings = await uow.campaign_settings_service.get()
    if not settings.campaign_enabled:
        await callback.message.edit_text(texts.campaign_disabled_text())
        await callback.answer()
        return

    membership_service = MembershipService(bot, settings.channel_id)
    status = await membership_service.check_membership(user.telegram_id)
    await uow.user_repo.set_membership_status(user, status)

    if status == MembershipStatus.MEMBER:
        await uow.referral_service.on_membership_confirmed(user)
        await callback.message.edit_text(
            texts.membership_confirmed(), reply_markup=None
        )
        # Hand off to the profile-questions flow.
        from app.bot.handlers.profile import start_profile_flow

        await start_profile_flow(callback.message, uow)
    else:
        await callback.message.edit_text(
            texts.join_channel_prompt(), reply_markup=join_channel_keyboard(settings.channel_link)
        )

    await callback.answer()


@router.callback_query(F.data == CB_SHOW_RULES)
async def handle_show_rules(callback: CallbackQuery) -> None:
    if callback.message is None:
        await callback.answer()
        return
    from app.bot.keyboards.menu import back_to_menu_keyboard

    await callback.message.edit_text(texts.rules_text(), reply_markup=back_to_menu_keyboard())
    await callback.answer()


@router.callback_query(F.data == CB_BACK_TO_MENU)
async def handle_back_to_menu(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return
    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    show_dashboard = bool(user and user.has_completed_profile)
    await callback.message.edit_text(texts.welcome_text(), reply_markup=welcome_keyboard(show_dashboard=show_dashboard))
    await callback.answer()
