"""
Router registry.

Order matters for the "answers" router: it must be registered before any
router that might otherwise also match callback_data starting with "ans:".
Since profile.py/activity.py no longer register a handler for that prefix
(see answers.py docstring), this is defensive but not load-bearing.

The chat_member router must be included with allowed_updates covering
'chat_member' in the dispatcher's polling/webhook start (see app/main.py).
"""
from app.bot.handlers import (
    activity,  # noqa: F401 - imported for side effects (helper functions used by answers.py)
    admin,
    answers,
    chat_member,
    dashboard,
    membership,
    profile,
    rules,
    start,
    status_command,
)

all_routers = [
    start.router,
    membership.router,
    answers.router,
    profile.router,
    dashboard.router,
    rules.router,
    status_command.router,
    chat_member.router,
    admin.router,
]

__all__ = ["all_routers"]
