"""
Activity questions flow helpers.

Rule #13: each invited referral must answer 5 short trading-activity
questions inside the bot. Progress is recomputed from saved Answer rows
(scoped by referral_id — see app/database/models/question.py docstring for
why activity answers carry a referral_id while profile answers don't).

NOTE: the actual "ans:" callback is handled centrally in
app/bot/handlers/answers.py — see that module's docstring for why.
"""
from __future__ import annotations

import logging

from aiogram.types import CallbackQuery, Message

from app.bot import texts
from app.bot.keyboards.questions import question_keyboard
from app.database.models import Question, QuestionSet
from app.services import UnitOfWork

logger = logging.getLogger(__name__)


async def _next_unanswered_activity_question(uow: UnitOfWork, user_id: int, referral_id: int):
    questions = await uow.question_repo.list_active(QuestionSet.ACTIVITY)
    answers = await uow.question_repo.list_answers_for_user(
        user_id=user_id, question_set=QuestionSet.ACTIVITY, referral_id=referral_id
    )
    answered_question_ids = {a.question_id for a in answers}
    for question in questions:
        if question.id not in answered_question_ids:
            return question, len(answered_question_ids) + 1, len(questions)
    return None, len(questions), len(questions)


async def start_activity_flow(message: Message, uow: UnitOfWork, user_id: int) -> None:
    """Called once a referred user's own /start or dashboard visit happens after
    they've joined the channel — they complete activities for their OWN inbound referral."""
    referral = await uow.referral_repo.get_by_referred_user_id(user_id)
    if referral is None:
        return  # organic user with no inbound referral; nothing to do

    if referral.activities_completed:
        return

    question, index, total = await _next_unanswered_activity_question(uow, user_id, referral.id)
    if question is None:
        await _finalize_activities(message, uow, user_id, referral.id)
        return

    await message.answer(
        texts.activity_progress(index, total, question.text),
        reply_markup=question_keyboard(question),
    )


async def handle_activity_answer(
    callback: CallbackQuery, uow: UnitOfWork, question: Question, option_id: int
) -> None:
    """Called by the central answers router once it has confirmed `question`
    belongs to QuestionSet.ACTIVITY."""
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    referral = await uow.referral_repo.get_by_referred_user_id(user.id)
    if referral is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    option = await uow.question_repo.get_option(option_id)
    if option is None or option.question_id != question.id:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    await uow.question_repo.upsert_answer(
        user_id=user.id, question_id=question.id, option_id=option_id, referral_id=referral.id
    )

    answers = await uow.question_repo.list_answers_for_user(
        user_id=user.id, question_set=QuestionSet.ACTIVITY, referral_id=referral.id
    )
    await uow.referral_service.record_activity_progress(referral, completed_count=len(answers))

    next_question, index, total = await _next_unanswered_activity_question(uow, user.id, referral.id)
    await callback.answer(texts.activity_completed_notice())

    if next_question is None:
        await _finalize_activities(callback.message, uow, user.id, referral.id)
        return

    await callback.message.edit_text(
        texts.activity_progress(index, total, next_question.text),
        reply_markup=question_keyboard(next_question),
    )


async def _finalize_activities(message: Message, uow: UnitOfWork, user_id: int, referral_id: int) -> None:
    from app.bot.keyboards.menu import dashboard_keyboard

    await message.answer(
        "✅ فعالیت‌های معاملاتی شما با موفقیت ثبت شد.",
        reply_markup=dashboard_keyboard(),
    )
