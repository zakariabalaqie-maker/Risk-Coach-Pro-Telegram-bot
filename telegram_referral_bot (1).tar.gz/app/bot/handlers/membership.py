"""Membership check handler (rule #7)."""
from __future__ import annotations

import logging

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery

from app.bot import texts
from app.bot.keyboards.menu import CB_CHECK_MEMBERSHIP, join_channel_keyboard
from app.database.models import MembershipStatus
from app.services import MembershipService, UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="membership")


@router.callback_query(F.data == CB_CHECK_MEMBERSHIP)
async def handle_check_membership(callback: CallbackQuery, uow: UnitOfWork, bot: Bot) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    settings = await uow.campaign_settings_service.get()
    membership_service = MembershipService(bot, settings.channel_id)
    status = await membership_service.check_membership(user.telegram_id)
    await uow.user_repo.set_membership_status(user, status)

    if status == MembershipStatus.MEMBER:
        await uow.referral_service.on_membership_confirmed(user)
        await callback.message.edit_text(texts.membership_confirmed())
        await callback.answer()

        from app.bot.handlers.profile import start_profile_flow

        await start_profile_flow(callback.message, uow)
        return

    await callback.answer(texts.membership_not_confirmed(), show_alert=True)
    # Keep the join-channel screen visible so the user can retry.
    try:
        await callback.message.edit_reply_markup(reply_markup=join_channel_keyboard(settings.channel_link))
    except Exception:  # noqa: BLE001 - message content/markup identical is a common harmless Telegram error
        pass
