"""
Dashboard handler.

Covers rule #10 (user dashboard), #15 (reward claim), and #20 (leaderboard).
"""
from __future__ import annotations

import logging

from aiogram import F, Router

from app.bot import texts
from app.bot.keyboards.menu import (
    CB_CLAIM_REWARD,
    CB_DASHBOARD,
    CB_LEADERBOARD,
    CB_MY_INVITE_LINK,
    CB_MY_REFERRALS,
    back_to_menu_keyboard,
    dashboard_keyboard,
    reward_locked_keyboard,
    reward_unlocked_keyboard,
)
from app.database.models import ReferralStatus, RewardStatus
from app.services import UnitOfWork
from aiogram.types import CallbackQuery

logger = logging.getLogger(__name__)

router = Router(name="dashboard")

_STATUS_EMOJI = {
    ReferralStatus.PENDING: "🟡",
    ReferralStatus.JOINED: "🟡",
    ReferralStatus.WAITING_8_HOURS: "🟡",
    ReferralStatus.QUESTIONS_PENDING: "🟡",
    ReferralStatus.VALID: "🟢",
    ReferralStatus.LEFT: "🔴",
    ReferralStatus.INVALID: "🔴",
}

_STATUS_LABEL_FA = {
    ReferralStatus.PENDING: "در انتظار عضویت",
    ReferralStatus.JOINED: "عضو شده، در انتظار ۸ ساعت",
    ReferralStatus.WAITING_8_HOURS: "در انتظار تکمیل ۸ ساعت",
    ReferralStatus.QUESTIONS_PENDING: "در انتظار تکمیل فعالیت‌ها",
    ReferralStatus.VALID: "معتبر",
    ReferralStatus.LEFT: "خارج شده از کانال",
    ReferralStatus.INVALID: "نامعتبر",
}


@router.callback_query(F.data == CB_DASHBOARD)
async def handle_dashboard(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    settings = await uow.campaign_settings_service.get()
    breakdown = await uow.referral_service.get_referral_breakdown(user.id)
    reward = await uow.reward_service.get_or_init_reward(user)

    text = texts.dashboard_text(
        valid=breakdown["valid"],
        waiting=breakdown["waiting"],
        invalid=breakdown["invalid"],
        required=settings.required_referrals,
        reward_locked=(reward.status == RewardStatus.LOCKED),
    )
    await callback.message.edit_text(
        text, reply_markup=dashboard_keyboard(reward_unlocked=(reward.status != RewardStatus.LOCKED))
    )
    await callback.answer()


@router.callback_query(F.data == CB_MY_INVITE_LINK)
async def handle_my_invite_link(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    me = await callback.bot.get_me()
    link = f"https://t.me/{me.username}?start={user.referral_code}"

    await callback.message.edit_text(
        texts.invite_link_text(link, user.referral_code), reply_markup=back_to_menu_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == CB_MY_REFERRALS)
async def handle_my_referrals(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    referrals = await uow.referral_repo.list_by_referrer(user.id)

    lines = [texts.my_referrals_header(len(referrals))]
    for index, referral in enumerate(referrals[:30], start=1):
        referred = referral.referred_user
        label = f"@{referred.username}" if referred.username else f"User#{referred.telegram_id}"
        emoji = _STATUS_EMOJI.get(referral.status, "⚪️")
        status_text = _STATUS_LABEL_FA.get(referral.status, referral.status.value)
        lines.append(texts.my_referrals_row(index, label, emoji, status_text))

    await callback.message.edit_text("\n".join(lines), reply_markup=back_to_menu_keyboard())
    await callback.answer()


@router.callback_query(F.data == CB_LEADERBOARD)
async def handle_leaderboard(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    top_users = await uow.user_repo.leaderboard(limit=10)
    medals = ["🥇", "🥈", "🥉"]

    lines = [texts.leaderboard_header()]
    for index, top_user in enumerate(top_users, start=1):
        medal = medals[index - 1] if index <= 3 else "▫️"
        label = f"@{top_user.username}" if top_user.username else f"User#{top_user.telegram_id}"
        lines.append(texts.leaderboard_row(index, medal, label, top_user.valid_referrals_count))

    your_rank = await uow.user_repo.rank_of(user)
    lines.append(texts.leaderboard_your_rank(your_rank, user.valid_referrals_count))

    await callback.message.edit_text("\n".join(lines), reply_markup=back_to_menu_keyboard())
    await callback.answer()


@router.callback_query(F.data == CB_CLAIM_REWARD)
async def handle_claim_reward(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    success, reward = await uow.reward_service.claim(user)

    if reward.status == RewardStatus.CLAIMED and not success:
        # Already claimed previously (idempotent no-op path).
        await callback.answer(texts.reward_already_claimed_notice(), show_alert=True)
        await callback.message.edit_text(
            texts.reward_claimed_text(
                reward.reward_title_snapshot or "", reward.reward_description_snapshot or ""
            ),
            reply_markup=back_to_menu_keyboard(),
        )
        return

    if reward.status == RewardStatus.LOCKED:
        settings = await uow.campaign_settings_service.get()
        breakdown = await uow.referral_service.get_referral_breakdown(user.id)
        await callback.answer()
        await callback.message.edit_text(
            texts.reward_locked_text(settings.required_referrals, breakdown["valid"]),
            reply_markup=reward_locked_keyboard(),
        )
        return

    # success == True: freshly claimed just now.
    await callback.answer()
    await callback.message.edit_text(
        texts.reward_claimed_text(reward.reward_title_snapshot or "", reward.reward_description_snapshot or ""),
        reply_markup=back_to_menu_keyboard(),
    )
