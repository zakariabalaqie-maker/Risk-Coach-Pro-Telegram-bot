"""Standalone /status command — text shortcut into the dashboard (rule #10)."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.bot import texts
from app.bot.keyboards.menu import dashboard_keyboard
from app.database.models import RewardStatus
from app.services import UnitOfWork

router = Router(name="status")


@router.message(Command("status"))
async def handle_status_command(message: Message, uow: UnitOfWork) -> None:
    if message.from_user is None:
        return

    user = await uow.user_repo.get_by_telegram_id(message.from_user.id)
    if user is None or not user.has_completed_profile:
        await message.answer("لطفاً ابتدا با /start کمپین را شروع کنید.")
        return

    settings = await uow.campaign_settings_service.get()
    breakdown = await uow.referral_service.get_referral_breakdown(user.id)
    reward = await uow.reward_service.get_or_init_reward(user)

    text = texts.dashboard_text(
        valid=breakdown["valid"],
        waiting=breakdown["waiting"],
        invalid=breakdown["invalid"],
        required=settings.required_referrals,
        reward_locked=(reward.status == RewardStatus.LOCKED),
    )
    await message.answer(
        text, reply_markup=dashboard_keyboard(reward_unlocked=(reward.status != RewardStatus.LOCKED))
    )
