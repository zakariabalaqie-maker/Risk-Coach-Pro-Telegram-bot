"""
Central answers router.

Both the PROFILE question set (rule #8) and the ACTIVITY question set
(rule #13) use the same "ans:{question_id}:{option_id}" callback_data
shape and the same inline-keyboard rendering. Rather than registering two
separate handlers on the same `F.data.startswith("ans:")` filter (which is
ambiguous — only the first-registered router would ever see it), this
module is the SINGLE place that receives that callback, looks up the
question's `question_set`, and dispatches to the appropriate flow's answer
handler. This must be the only router registered for this filter.
"""
from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot import texts
from app.bot.handlers.activity import handle_activity_answer
from app.bot.handlers.profile import handle_profile_answer
from app.bot.keyboards.questions import parse_answer_callback
from app.database.models import QuestionSet
from app.services import UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="answers")


@router.callback_query(F.data.startswith("ans:"))
async def handle_answer(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.data is None:
        await callback.answer()
        return

    try:
        question_id, option_id = parse_answer_callback(callback.data)
    except ValueError:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    question = await uow.question_repo.get_by_id(question_id)
    if question is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    if question.question_set == QuestionSet.PROFILE:
        await handle_profile_answer(callback, uow, question, option_id)
    elif question.question_set == QuestionSet.ACTIVITY:
        await handle_activity_answer(callback, uow, question, option_id)
    else:  # pragma: no cover - defensive, no other question sets exist today
        await callback.answer(texts.generic_error_text(), show_alert=True)
