"""
Admin panel handlers.

Rule #16 (admin panel), #17 (campaign settings), #18 (user management),
#19 (fraud review). All routes here are protected by AdminAuthMiddleware,
applied to this router in main.py — no handler in this module re-checks
authorization itself.

Every mutating admin action is written to admin_logs via
AdminLogRepository.log(...) — see rule #18's audit-trail requirement.
"""
from __future__ import annotations

import logging
from datetime import timedelta

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards.admin import (
    CB_ADMIN_BROADCAST,
    CB_ADMIN_FRAUD,
    CB_ADMIN_FRAUD_CLEAR,
    CB_ADMIN_FRAUD_CONFIRM,
    CB_ADMIN_REFERRAL_FORCE_INVALID,
    CB_ADMIN_REFERRAL_FORCE_VALID,
    CB_ADMIN_REFERRALS,
    CB_ADMIN_REWARDS,
    CB_ADMIN_ROOT,
    CB_ADMIN_SETTING_EDIT_PREFIX,
    CB_ADMIN_SETTINGS,
    CB_ADMIN_STATS,
    CB_ADMIN_USER_BLOCK,
    CB_ADMIN_USER_UNBLOCK,
    CB_ADMIN_USER_VIEW_PROFILE,
    CB_ADMIN_USER_VIEW_REFERRALS,
    CB_ADMIN_USERS,
    admin_back_keyboard,
    admin_cancel_keyboard,
    admin_fraud_flag_keyboard,
    admin_referral_override_keyboard,
    admin_root_keyboard,
    admin_settings_keyboard,
    admin_user_actions_keyboard,
)
from app.bot.states import AdminBroadcastFlow, AdminSettingsFlow, AdminUserSearchFlow
from app.database.models import ReferralStatus, RewardStatus, utcnow
from app.services import UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="admin")


# ----------------------------------------------------------------------
# Root menu
# ----------------------------------------------------------------------


@router.message(Command("admin"))
async def handle_admin_command(message: Message) -> None:
    await message.answer("⚙️ ADMIN PANEL", reply_markup=admin_root_keyboard())


@router.callback_query(F.data == CB_ADMIN_ROOT)
async def handle_admin_root(callback: CallbackQuery) -> None:
    if callback.message is None:
        await callback.answer()
        return
    await callback.message.edit_text("⚙️ ADMIN PANEL", reply_markup=admin_root_keyboard())
    await callback.answer()


# ----------------------------------------------------------------------
# Users (rule #18)
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_USERS)
async def handle_admin_users(callback: CallbackQuery, state: FSMContext) -> None:
    if callback.message is None:
        await callback.answer()
        return
    await state.set_state(AdminUserSearchFlow.awaiting_query)
    await callback.message.edit_text(
        "👥 Users\n\nUsername یا Telegram ID کاربر را ارسال کنید تا جستجو شود.",
        reply_markup=admin_back_keyboard(),
    )
    await callback.answer()


@router.message(AdminUserSearchFlow.awaiting_query)
async def handle_admin_user_search_query(message: Message, uow: UnitOfWork, state: FSMContext) -> None:
    if not message.text:
        return
    await state.clear()
    results = await uow.user_repo.search_by_username_or_id(message.text, limit=5)

    if not results:
        await message.answer("کاربری یافت نشد.", reply_markup=admin_back_keyboard())
        return

    for user in results:
        label = f"@{user.username}" if user.username else f"User#{user.telegram_id}"
        block_state = "🚫 Blocked" if user.is_blocked else "✅ Active"
        text = (
            f"👤 {label}\n"
            f"Telegram ID: <code>{user.telegram_id}</code>\n"
            f"Referral code: <code>{user.referral_code}</code>\n"
            f"Valid referrals: {user.valid_referrals_count}\n"
            f"Status: {block_state}\n"
            f"Membership: {user.membership_status.value}\n"
        )
        await message.answer(text, reply_markup=admin_user_actions_keyboard(user.id, is_blocked=user.is_blocked))


@router.callback_query(F.data.startswith(f"{CB_ADMIN_USER_BLOCK}:"))
async def handle_admin_block_user(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    user_id = int(callback.data.split(":")[-1])
    target = await uow.user_repo.get_by_id(user_id)
    if target is None:
        await callback.answer("User not found", show_alert=True)
        return

    target.is_blocked = True
    target.blocked_reason = "Blocked by admin"

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="block_user",
        target_type="user",
        target_id=target.id,
    )

    await callback.answer("✅ User blocked")
    await callback.message.edit_reply_markup(reply_markup=admin_user_actions_keyboard(target.id, is_blocked=True))


@router.callback_query(F.data.startswith(f"{CB_ADMIN_USER_UNBLOCK}:"))
async def handle_admin_unblock_user(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    user_id = int(callback.data.split(":")[-1])
    target = await uow.user_repo.get_by_id(user_id)
    if target is None:
        await callback.answer("User not found", show_alert=True)
        return

    target.is_blocked = False
    target.blocked_reason = None

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="unblock_user",
        target_type="user",
        target_id=target.id,
    )

    await callback.answer("✅ User unblocked")
    await callback.message.edit_reply_markup(reply_markup=admin_user_actions_keyboard(target.id, is_blocked=False))


@router.callback_query(F.data.startswith(f"{CB_ADMIN_USER_VIEW_REFERRALS}:"))
async def handle_admin_view_user_referrals(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.data is None:
        await callback.answer()
        return
    user_id = int(callback.data.split(":")[-1])
    referrals = await uow.referral_repo.list_by_referrer(user_id)

    if not referrals:
        await callback.answer("این کاربر هیچ ریفرالی ندارد", show_alert=True)
        return

    lines = [f"👥 Referrals for user #{user_id} ({len(referrals)}):\n"]
    for r in referrals[:30]:
        referred_label = f"@{r.referred_user.username}" if r.referred_user.username else f"#{r.referred_user.telegram_id}"
        lines.append(f"• {referred_label} — {r.status.value}")

    await callback.message.answer("\n".join(lines))
    await callback.answer()


@router.callback_query(F.data.startswith(f"{CB_ADMIN_USER_VIEW_PROFILE}:"))
async def handle_admin_view_user_profile(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.data is None:
        await callback.answer()
        return
    user_id = int(callback.data.split(":")[-1])
    profile = await uow.profile_service.get_existing(user_id)

    if profile is None:
        await callback.answer("این کاربر پروفایل ندارد", show_alert=True)
        return

    text = (
        f"🧠 Profile for user #{user_id}\n\n"
        f"Experience: {profile.experience_label}\n"
        f"Market: {profile.primary_market_label}\n"
        f"Challenge: {profile.main_challenge_label}\n"
        f"Risk: {profile.typical_risk_label}\n"
        f"Tool: {profile.preferred_tool_label}\n"
        f"Risk Awareness: {profile.risk_awareness_score}/100"
    )
    await callback.message.answer(text)
    await callback.answer()


# ----------------------------------------------------------------------
# Statistics (rule #16)
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_STATS)
async def handle_admin_stats(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None:
        await callback.answer()
        return

    total_users = await uow.user_repo.count_total()
    active_users = await uow.user_repo.count_active_since(utcnow() - timedelta(days=7))
    total_referrals = await uow.referral_repo.count_total()
    valid_referrals = await uow.referral_repo.count_by_status([ReferralStatus.VALID])
    invalid_referrals = await uow.referral_repo.count_by_status(
        [ReferralStatus.INVALID, ReferralStatus.LEFT]
    )
    rewards_unlocked = await uow.reward_repo.count_by_status(RewardStatus.UNLOCKED) + await uow.reward_repo.count_by_status(
        RewardStatus.CLAIMED
    )
    rewards_claimed = await uow.reward_repo.count_by_status(RewardStatus.CLAIMED)

    conversion_rate = (valid_referrals / total_referrals * 100) if total_referrals else 0.0

    text = (
        "📊 <b>Statistics</b>\n\n"
        f"Total Users: {total_users}\n"
        f"Active Users (7d): {active_users}\n"
        f"Total Referrals: {total_referrals}\n"
        f"Valid Referrals: {valid_referrals}\n"
        f"Invalid Referrals: {invalid_referrals}\n"
        f"Rewards Unlocked: {rewards_unlocked}\n"
        f"Rewards Claimed: {rewards_claimed}\n"
        f"Conversion Rate: {conversion_rate:.1f}%"
    )
    await callback.message.edit_text(text, reply_markup=admin_back_keyboard())
    await callback.answer()


# ----------------------------------------------------------------------
# Referrals — manual valid/invalid override (rule #18)
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_REFERRALS)
async def handle_admin_referrals(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None:
        await callback.answer()
        return

    pending = await uow.referral_repo.list_by_status(
        [ReferralStatus.QUESTIONS_PENDING, ReferralStatus.WAITING_8_HOURS], limit=10
    )

    if not pending:
        await callback.message.edit_text(
            "🔗 Referrals\n\nهیچ ریفرال در انتظار بررسی وجود ندارد.", reply_markup=admin_back_keyboard()
        )
        await callback.answer()
        return

    await callback.message.edit_text(f"🔗 Referrals — {len(pending)} در انتظار بررسی:", reply_markup=admin_back_keyboard())
    for r in pending:
        referred_label = f"@{r.referred_user.username}" if r.referred_user.username else f"#{r.referred_user.telegram_id}"
        referrer_label = f"@{r.referrer.username}" if r.referrer.username else f"#{r.referrer.telegram_id}"
        text = (
            f"Referral #{r.id}\n"
            f"Referrer: {referrer_label}\n"
            f"Referred: {referred_label}\n"
            f"Status: {r.status.value}\n"
            f"Activities: {'✅' if r.activities_completed else '❌'}"
        )
        await callback.message.answer(text, reply_markup=admin_referral_override_keyboard(r.id))
    await callback.answer()


@router.callback_query(F.data.startswith(f"{CB_ADMIN_REFERRAL_FORCE_VALID}:"))
async def handle_admin_force_valid(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    referral_id = int(callback.data.split(":")[-1])
    referral = await uow.referral_repo.get_by_id(referral_id)
    if referral is None:
        await callback.answer("Referral not found", show_alert=True)
        return

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.referral_service.admin_set_status(
        referral, status=ReferralStatus.VALID, admin_user_id=(admin_user.id if admin_user else 0)
    )
    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="force_referral_valid",
        target_type="referral",
        target_id=referral.id,
    )
    await callback.answer("✅ Referral forced VALID")
    await callback.message.edit_text(f"Referral #{referral.id} → VALID (manual override)")


@router.callback_query(F.data.startswith(f"{CB_ADMIN_REFERRAL_FORCE_INVALID}:"))
async def handle_admin_force_invalid(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    referral_id = int(callback.data.split(":")[-1])
    referral = await uow.referral_repo.get_by_id(referral_id)
    if referral is None:
        await callback.answer("Referral not found", show_alert=True)
        return

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.referral_service.admin_set_status(
        referral, status=ReferralStatus.INVALID, admin_user_id=(admin_user.id if admin_user else 0)
    )
    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="force_referral_invalid",
        target_type="referral",
        target_id=referral.id,
    )
    await callback.answer("🚫 Referral forced INVALID")
    await callback.message.edit_text(f"Referral #{referral.id} → INVALID (manual override)")


# ----------------------------------------------------------------------
# Rewards (rule #16)
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_REWARDS)
async def handle_admin_rewards(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None:
        await callback.answer()
        return

    unlocked = await uow.reward_repo.count_by_status(RewardStatus.UNLOCKED)
    claimed = await uow.reward_repo.count_by_status(RewardStatus.CLAIMED)
    locked = await uow.reward_repo.count_by_status(RewardStatus.LOCKED)

    text = (
        "🎁 <b>Rewards</b>\n\n"
        f"Locked: {locked}\n"
        f"Unlocked (not yet claimed): {unlocked}\n"
        f"Claimed: {claimed}"
    )
    await callback.message.edit_text(text, reply_markup=admin_back_keyboard())
    await callback.answer()


# ----------------------------------------------------------------------
# Fraud (rule #19)
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_FRAUD)
async def handle_admin_fraud(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None:
        await callback.answer()
        return

    open_flags = await uow.fraud_repo.list_open(limit=10)
    if not open_flags:
        await callback.message.edit_text(
            "🛡️ Fraud\n\nهیچ مورد باز برای بررسی وجود ندارد.", reply_markup=admin_back_keyboard()
        )
        await callback.answer()
        return

    await callback.message.edit_text(f"🛡️ Fraud — {len(open_flags)} مورد باز:", reply_markup=admin_back_keyboard())
    for flag in open_flags:
        user_label = f"@{flag.user.username}" if flag.user.username else f"#{flag.user.telegram_id}"
        text = f"Flag #{flag.id} — {flag.flag_type.value}\nUser: {user_label}\nDetail: {flag.detail or '-'}"
        await callback.message.answer(text, reply_markup=admin_fraud_flag_keyboard(flag.id))
    await callback.answer()


@router.callback_query(F.data.startswith(f"{CB_ADMIN_FRAUD_CLEAR}:"))
async def handle_admin_fraud_clear(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    flag_id = int(callback.data.split(":")[-1])
    flag = await uow.fraud_repo.get_by_id(flag_id)
    if flag is None:
        await callback.answer("Flag not found", show_alert=True)
        return

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.fraud_repo.review(flag, admin_id=(admin_user.id if admin_user else 0), confirmed=False)
    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="fraud_flag_cleared",
        target_type="fraud_flag",
        target_id=flag.id,
    )
    await callback.answer("✅ Marked clean")
    await callback.message.edit_text(f"Flag #{flag.id} → reviewed, clean.")


@router.callback_query(F.data.startswith(f"{CB_ADMIN_FRAUD_CONFIRM}:"))
async def handle_admin_fraud_confirm(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None or callback.data is None:
        await callback.answer()
        return
    flag_id = int(callback.data.split(":")[-1])
    flag = await uow.fraud_repo.get_by_id(flag_id)
    if flag is None:
        await callback.answer("Flag not found", show_alert=True)
        return

    admin_user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    await uow.fraud_repo.review(flag, admin_id=(admin_user.id if admin_user else 0), confirmed=True)

    # A confirmed fraud flag on a referral invalidates it directly.
    if flag.referral_id is not None:
        referral = await uow.referral_repo.get_by_id(flag.referral_id)
        if referral is not None:
            await uow.referral_service.admin_set_status(
                referral, status=ReferralStatus.INVALID, admin_user_id=(admin_user.id if admin_user else 0)
            )

    await uow.admin_log_repo.log(
        admin_telegram_id=callback.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="fraud_flag_confirmed",
        target_type="fraud_flag",
        target_id=flag.id,
    )
    await callback.answer("🚫 Marked confirmed")
    await callback.message.edit_text(f"Flag #{flag.id} → reviewed, confirmed fraud.")


# ----------------------------------------------------------------------
# Campaign Settings (rule #17)
# ----------------------------------------------------------------------

_SETTING_FIELD_TYPES = {
    "required_referrals": int,
    "membership_hours": int,
    "required_activities": int,
    "reward_title": str,
    "reward_description": str,
    "channel_id": str,
    "channel_link": str,
}


@router.callback_query(F.data == CB_ADMIN_SETTINGS)
async def handle_admin_settings(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None:
        await callback.answer()
        return

    settings = await uow.campaign_settings_service.get()
    text = (
        "⚙️ <b>Campaign Settings</b>\n\n"
        f"required_referrals: {settings.required_referrals}\n"
        f"membership_hours: {settings.membership_hours}\n"
        f"required_activities: {settings.required_activities}\n"
        f"reward_title: {settings.reward_title}\n"
        f"reward_description: {settings.reward_description}\n"
        f"channel_id: {settings.channel_id or '-'}\n"
        f"channel_link: {settings.channel_link or '-'}\n"
        f"campaign_enabled: {settings.campaign_enabled}\n\n"
        "برای تغییر هر مقدار، روی دکمه مربوطه بزنید."
    )
    await callback.message.edit_text(text, reply_markup=admin_settings_keyboard())
    await callback.answer()


@router.callback_query(F.data.startswith(f"{CB_ADMIN_SETTING_EDIT_PREFIX}:"))
async def handle_admin_setting_edit_start(callback: CallbackQuery, uow: UnitOfWork, state: FSMContext) -> None:
    if callback.message is None or callback.data is None:
        await callback.answer()
        return
    field = callback.data.split(":")[-1]

    if field == "campaign_enabled":
        settings = await uow.campaign_settings_service.get()
        await uow.campaign_settings_service.update(campaign_enabled=not settings.campaign_enabled)
        await callback.answer(f"Toggled to {not settings.campaign_enabled}")
        await handle_admin_settings(callback, uow)
        return

    if field not in _SETTING_FIELD_TYPES:
        await callback.answer("Unknown field", show_alert=True)
        return

    await state.set_state(AdminSettingsFlow.awaiting_value)
    await state.update_data(field=field)
    await callback.message.edit_text(
        f"مقدار جدید برای <code>{field}</code> را ارسال کنید:", reply_markup=admin_cancel_keyboard()
    )
    await callback.answer()


@router.message(AdminSettingsFlow.awaiting_value)
async def handle_admin_setting_value(message: Message, uow: UnitOfWork, state: FSMContext) -> None:
    if not message.text or message.from_user is None:
        return

    data = await state.get_data()
    field = data.get("field")
    await state.clear()

    if field not in _SETTING_FIELD_TYPES:
        await message.answer("خطا: فیلد نامعتبر.")
        return

    field_type = _SETTING_FIELD_TYPES[field]
    raw_value = message.text.strip()

    try:
        value = field_type(raw_value)
    except ValueError:
        await message.answer(f"مقدار نامعتبر برای {field}. لطفاً دوباره تلاش کنید از منوی تنظیمات.")
        return

    if field in ("required_referrals", "membership_hours", "required_activities") and value <= 0:
        await message.answer("مقدار باید بزرگ‌تر از صفر باشد.")
        return

    await uow.campaign_settings_service.update(**{field: value})

    admin_user = await uow.user_repo.get_by_telegram_id(message.from_user.id)
    await uow.admin_log_repo.log(
        admin_telegram_id=message.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="update_campaign_setting",
        target_type="campaign_settings",
        detail=f"{field}={value}",
    )

    await message.answer(f"✅ {field} به‌روزرسانی شد.", reply_markup=admin_back_keyboard())


# ----------------------------------------------------------------------
# Broadcast
# ----------------------------------------------------------------------


@router.callback_query(F.data == CB_ADMIN_BROADCAST)
async def handle_admin_broadcast_start(callback: CallbackQuery, state: FSMContext) -> None:
    if callback.message is None:
        await callback.answer()
        return
    await state.set_state(AdminBroadcastFlow.awaiting_message)
    await callback.message.edit_text(
        "📢 Broadcast\n\nمتنی که می‌خواهید برای همه کاربران ارسال شود را بنویسید:",
        reply_markup=admin_back_keyboard(),
    )
    await callback.answer()


@router.message(AdminBroadcastFlow.awaiting_message)
async def handle_admin_broadcast_send(message: Message, uow: UnitOfWork, state: FSMContext) -> None:
    if not message.text or message.from_user is None:
        return
    await state.clear()

    # Broadcasts are dispatched by the scheduler-adjacent worker (see
    # app/scheduler/jobs.py::run_broadcast) to respect Telegram's outgoing
    # message rate limits (~30 msg/sec across the whole bot) rather than
    # firing them all from this single handler invocation.
    from app.scheduler.jobs import run_broadcast

    admin_user = await uow.user_repo.get_by_telegram_id(message.from_user.id)
    await uow.admin_log_repo.log(
        admin_telegram_id=message.from_user.id,
        admin_user_id=admin_user.id if admin_user else None,
        action="broadcast_sent",
        detail=message.text[:200],
    )

    await message.answer("⏳ در حال ارسال Broadcast... این کار ممکن است چند دقیقه طول بکشد.")
    sent, failed = await run_broadcast(message.bot, message.text)
    await message.answer(f"✅ Broadcast تمام شد. ارسال موفق: {sent} | ناموفق: {failed}")

