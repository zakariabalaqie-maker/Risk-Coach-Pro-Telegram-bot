"""
Chat member update handler.

Reactive fast-path for membership changes: Telegram pushes a
`chat_member` update to bots that administer a channel whenever a user's
membership status changes there, PROVIDED the bot subscribes to it via
`allowed_updates` (done in main.py's polling/webhook setup).

This is faster than waiting for the scheduler's periodic re-check, but is
NOT solely relied upon — the scheduler (app/scheduler/jobs.py) independently
re-verifies membership via getChatMember for any referral still in a
non-terminal state, so a missed update here can never permanently strand a
referral (rule #12's explicit server-side re-verification requirement).

Known Telegram API limitation: `chat_member` updates are only delivered for
channels/groups where the bot is an admin, and only going forward from
whenever the bot started listening for them — historical membership changes
before the bot was configured are not backfillable. This is inherent to the
Bot API and is why the scheduler fallback exists.
"""
from __future__ import annotations

import logging

from aiogram import Router
from aiogram.types import ChatMemberUpdated

from app.bot.notifications import referral_left_channel, referral_validated
from app.database.models import MembershipStatus
from app.services import UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="chat_member")

_MEMBER_STATUSES = {"member", "administrator", "creator"}
_LEFT_STATUSES = {"left", "kicked"}


@router.chat_member()
async def handle_chat_member_update(event: ChatMemberUpdated, uow: UnitOfWork) -> None:
    settings = await uow.campaign_settings_service.get()
    if not settings.channel_id:
        return

    # Only care about updates for the configured campaign channel.
    if str(event.chat.id) != str(settings.channel_id) and f"@{event.chat.username}" != settings.channel_id:
        return

    telegram_user = event.new_chat_member.user
    if telegram_user.is_bot:
        return

    user = await uow.user_repo.get_by_telegram_id(telegram_user.id)
    if user is None:
        return  # hasn't interacted with the bot at all; nothing to update

    new_status = event.new_chat_member.status

    if new_status in _MEMBER_STATUSES:
        await uow.user_repo.set_membership_status(user, MembershipStatus.MEMBER)
        await uow.referral_service.on_membership_confirmed(user)
    elif new_status in _LEFT_STATUSES:
        status_enum = MembershipStatus.KICKED if new_status == "kicked" else MembershipStatus.LEFT
        await uow.user_repo.set_membership_status(user, status_enum)
        was_valid_referral = await _was_referral_valid_before(uow, user.id)
        await uow.referral_service.on_membership_lost(user)

        if was_valid_referral:
            referral = await uow.referral_repo.get_by_referred_user_id(user.id)
            if referral is not None:
                referrer = await uow.user_repo.get_by_id(referral.referrer_id)
                if referrer is not None:
                    try:
                        from app.bot import notifications as notif_module

                        bot = event.bot
                        await bot.send_message(referrer.telegram_id, referral_left_channel())
                    except Exception:  # noqa: BLE001
                        logger.exception("Failed to notify referrer about lost referral")


async def _was_referral_valid_before(uow: UnitOfWork, referred_user_id: int) -> bool:
    from app.database.models import ReferralStatus

    referral = await uow.referral_repo.get_by_referred_user_id(referred_user_id)
    return referral is not None and referral.status == ReferralStatus.VALID
