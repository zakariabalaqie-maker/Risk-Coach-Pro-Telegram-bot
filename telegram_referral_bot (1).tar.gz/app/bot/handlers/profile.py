"""
Profile questions flow helpers.

Rule #8/#9: 5-question trader profile, shown via inline keyboard, scored
deterministically. Progress is always recomputed from saved Answer rows —
NOT from FSM state — so a bot restart mid-flow loses nothing (rule #2).

NOTE: the actual "ans:" callback is handled centrally in
app/bot/handlers/answers.py, which inspects the question's QuestionSet and
dispatches to `handle_profile_answer` (below) or the activity-flow
equivalent. This avoids two routers both matching the same callback prefix
ambiguously.
"""
from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from app.bot import texts
from app.bot.keyboards.menu import CB_MY_PROFILE, back_to_menu_keyboard
from app.bot.keyboards.questions import question_keyboard
from app.database.models import Question, QuestionSet
from app.services import UnitOfWork

logger = logging.getLogger(__name__)

router = Router(name="profile")


async def _next_unanswered_question(uow: UnitOfWork, user_id: int):
    questions = await uow.question_repo.list_active(QuestionSet.PROFILE)
    answers = await uow.question_repo.list_answers_for_user(user_id=user_id, question_set=QuestionSet.PROFILE)
    answered_question_ids = {a.question_id for a in answers}
    for question in questions:
        if question.id not in answered_question_ids:
            return question, len(answered_question_ids) + 1, len(questions)
    return None, len(questions), len(questions)


async def start_profile_flow(message: Message, uow: UnitOfWork) -> None:
    """Entry point called after membership is confirmed, or when user revisits an incomplete profile."""
    tg_user = message.chat
    user = await uow.user_repo.get_by_telegram_id(tg_user.id)
    if user is None:
        await message.answer(texts.generic_error_text())
        return

    if user.has_completed_profile:
        await _send_profile_result(message, uow, user.id)
        return

    question, index, total = await _next_unanswered_question(uow, user.id)
    if question is None:
        await _finalize_profile(message, uow, user.id)
        return

    await message.answer(
        texts.profile_question_progress(index, total, question.text),
        reply_markup=question_keyboard(question),
    )


async def handle_profile_answer(
    callback: CallbackQuery, uow: UnitOfWork, question: Question, option_id: int
) -> None:
    """Called by the central answers router once it has confirmed `question`
    belongs to QuestionSet.PROFILE."""
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    option = await uow.question_repo.get_option(option_id)
    if option is None or option.question_id != question.id:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    await uow.question_repo.upsert_answer(
        user_id=user.id, question_id=question.id, option_id=option_id, referral_id=None
    )

    next_question, index, total = await _next_unanswered_question(uow, user.id)
    await callback.answer()

    if next_question is None:
        await _finalize_profile(callback.message, uow, user.id)
        return

    await callback.message.edit_text(
        texts.profile_question_progress(index, total, next_question.text),
        reply_markup=question_keyboard(next_question),
    )


async def _finalize_profile(message: Message, uow: UnitOfWork, user_id: int) -> None:
    user = await uow.user_repo.get_by_id(user_id)
    if user is not None:
        user.has_completed_profile = True
    await uow.profile_service.compute_and_save(user_id)
    await _send_profile_result(message, uow, user_id)

    # If this user was themselves invited via a referral link, their own
    # 5 trading activities (rule #13) still need completing — chain
    # straight into that flow so they don't have to hunt for it.
    from app.bot.handlers.activity import start_activity_flow

    await start_activity_flow(message, uow, user_id)


async def _send_profile_result(message: Message, uow: UnitOfWork, user_id: int) -> None:
    result = await uow.profile_service.get_existing(user_id)
    if result is None:
        await message.answer(texts.generic_error_text())
        return

    from app.bot.keyboards.menu import dashboard_keyboard
    from app.database.models import RewardStatus

    user = await uow.user_repo.get_by_id(user_id)
    reward = await uow.reward_service.get_or_init_reward(user) if user else None
    reward_unlocked = bool(reward and reward.status != RewardStatus.LOCKED)

    await message.answer(
        texts.profile_result_text(
            experience=result.experience_label,
            market=result.primary_market_label,
            challenge=result.main_challenge_label,
            risk=result.typical_risk_label,
            score=result.risk_awareness_score,
        ),
        reply_markup=dashboard_keyboard(reward_unlocked=reward_unlocked),
    )


@router.callback_query(F.data == CB_MY_PROFILE)
async def handle_view_profile(callback: CallbackQuery, uow: UnitOfWork) -> None:
    if callback.message is None or callback.from_user is None:
        await callback.answer()
        return

    user = await uow.user_repo.get_by_telegram_id(callback.from_user.id)
    if user is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    if not user.has_completed_profile:
        await callback.answer(texts.profile_required_first_text(), show_alert=True)
        return

    result = await uow.profile_service.get_existing(user.id)
    if result is None:
        await callback.answer(texts.generic_error_text(), show_alert=True)
        return

    await callback.message.edit_text(
        texts.profile_result_text(
            experience=result.experience_label,
            market=result.primary_market_label,
            challenge=result.main_challenge_label,
            risk=result.typical_risk_label,
            score=result.risk_awareness_score,
        ),
        reply_markup=back_to_menu_keyboard(),
    )
    await callback.answer()
