"""Standalone /rules command (rule #24 requires a Privacy section here too)."""
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.bot import texts

router = Router(name="rules")


@router.message(Command("rules"))
async def handle_rules_command(message: Message) -> None:
    await message.answer(texts.rules_text())
