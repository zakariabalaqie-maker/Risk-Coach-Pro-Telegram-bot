"""
Centralized Persian user-facing text templates (rule #26: all user messages
must be Persian; code/vars/schema stay English).

Keeping these in one module makes tone/consistency review easy and avoids
copy drifting between handlers.
"""
from __future__ import annotations


def welcome_text() -> str:
    return (
        "🎁 <b>اکسپرت معاملاتی ۲,۰۰۰ دلاری، رایگان</b>\n\n"
        "یک Expert Advisor حرفه‌ای را بدون پرداخت هزینه دریافت کنید.\n\n"
        "برای دریافت جایزه باید:\n"
        "👥 ۵ Referral معتبر ایجاد کنید\n"
        "⏱️ هر دعوت‌شده حداقل ۸ ساعت عضو کانال بماند\n"
        "🧠 فعالیت‌های معاملاتی را تکمیل کند\n\n"
        "👇 برای شروع:"
    )


def already_started_text() -> str:
    return "👋 خوش برگشتید! از منوی زیر ادامه دهید."


def invalid_referral_notice() -> str:
    return "ℹ️ لینک دعوتی که استفاده کردید معتبر نبود، اما می‌توانید عادی کمپین را شروع کنید."


def self_referral_notice() -> str:
    return "ℹ️ شما نمی‌توانید از لینک دعوت خودتان استفاده کنید. کمپین به‌صورت عادی برای شما آغاز می‌شود."


def join_channel_prompt() -> str:
    return "📢 ابتدا عضو کانال رسمی شوید."


def membership_not_confirmed() -> str:
    return "❌ هنوز عضویت شما تأیید نشده است."


def membership_confirmed() -> str:
    return "✅ عضویت شما تأیید شد."


def rules_text() -> str:
    return (
        "📜 <b>قوانین کمپین</b>\n\n"
        "۱. عضو کانال رسمی باشید.\n"
        "۲. ۵ سؤال اولیه معاملاتی را پاسخ دهید.\n"
        "۳. لینک ریفرال اختصاصی خود را دریافت کنید.\n"
        "۴. حداقل ۵ کاربر منحصربه‌فرد را از طریق لینک خود دعوت کنید.\n"
        "۵. هر کاربر دعوت‌شده حداقل ۸ ساعت عضو کانال بماند.\n"
        "۶. هر کاربر دعوت‌شده ۵ فعالیت معاملاتی را تکمیل کند.\n"
        "۷. با تکمیل ۵ دعوت معتبر، جایزه باز می‌شود.\n\n"
        "🔒 <b>حریم خصوصی</b>\n"
        "اطلاعات شما فقط برای اجرای کمپین، ردیابی ریفرال، جلوگیری از تقلب، "
        "تحلیل آماری و شخصی‌سازی تجربه استفاده می‌شود. ما هرگز رمز عبور، اطلاعات "
        "ورود بروکر یا کلیدهای خصوصی از شما درخواست نمی‌کنیم."
    )


def profile_question_progress(current: int, total: int, question_text: str) -> str:
    return f"🧠 سؤال {current} / {total}\n\n{question_text}"


def profile_result_text(
    experience: str, market: str, challenge: str, risk: str, score: int
) -> str:
    return (
        "🧠 <b>پروفایل معاملاتی شما</b>\n\n"
        f"سطح تجربه: {experience}\n"
        f"بازار اصلی: {market}\n"
        f"ریسک معمول: {risk}\n"
        f"چالش اصلی: {challenge}\n\n"
        f"Risk Awareness: {score}/100"
    )


def activity_progress(current: int, total: int, question_text: str) -> str:
    return f"🧠 Activity {current} / {total}\n\n{question_text}"


def activity_completed_notice() -> str:
    return "✅ Activity completed"


def dashboard_text(
    *, valid: int, waiting: int, invalid: int, required: int, reward_locked: bool
) -> str:
    reward_line = "🔒 Locked" if reward_locked else "🔓 Unlocked"
    return (
        "🎁 <b>وضعیت جایزه</b>\n\n"
        f"👥 Referral معتبر: {valid} / {required}\n\n"
        f"🟢 Valid: {valid}\n"
        f"🟡 Waiting: {waiting}\n"
        f"🔴 Invalid: {invalid}\n\n"
        f"🎁 Reward: {reward_line}"
    )


def invite_link_text(link: str, code: str) -> str:
    return (
        "🔗 <b>لینک دعوت اختصاصی شما</b>\n\n"
        f"<code>{link}</code>\n\n"
        f"کد شما: <code>{code}</code>\n\n"
        "این لینک را با تریدرهای دیگر به اشتراک بگذارید."
    )


def my_referrals_header(total: int) -> str:
    if total == 0:
        return "👥 هنوز هیچ دعوتی ثبت نشده است."
    return f"👥 <b>دعوت‌های من</b> ({total})"


def my_referrals_row(index: int, label: str, status_emoji: str, status_text: str) -> str:
    return f"{index}. {status_emoji} {label} — {status_text}"


def reward_locked_text(required: int, current: int) -> str:
    return (
        "🔒 جایزه قفل است.\n\n"
        f"برای دریافت اکسپرت $2,000 باید {required} Referral معتبر تکمیل کنید.\n"
        f"در حال حاضر: {current} / {required}"
    )


def reward_unlocked_text(title: str, description: str) -> str:
    return (
        "🎉 <b>تبریک!</b>\n\n"
        "شما کمپین را با موفقیت تکمیل کردید.\n\n"
        f"🎁 {title}\n"
        f"{description}\n"
        "💰 Commercial Value: $2,000\n\n"
        "Reward: UNLOCKED"
    )


def reward_claimed_text(title: str, description: str) -> str:
    return (
        "🎁 <b>جایزه شما</b>\n\n"
        f"{title}\n"
        f"{description}\n\n"
        "✅ این جایزه قبلاً برای شما ثبت و ارسال شده است.\n"
        "در صورت نیاز به راهنمایی بیشتر با پشتیبانی در تماس باشید."
    )


def reward_already_claimed_notice() -> str:
    return "ℹ️ شما قبلاً این جایزه را دریافت کرده‌اید."


def leaderboard_header() -> str:
    return "🏆 <b>TOP REFERRERS</b>\n"


def leaderboard_row(rank: int, medal: str, label: str, count: int) -> str:
    return f"{medal} #{rank} {label} — {count}"


def leaderboard_your_rank(rank: int, count: int) -> str:
    return f"\n────────────\n👤 You — #{rank} — {count}"


def campaign_disabled_text() -> str:
    return "⏸️ کمپین در حال حاضر غیرفعال است. لطفاً بعداً دوباره تلاش کنید."


def generic_error_text() -> str:
    return "⚠️ خطایی رخ داد. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید."


def profile_required_first_text() -> str:
    return "لطفاً ابتدا سؤالات پروفایل معاملاتی را تکمیل کنید."
