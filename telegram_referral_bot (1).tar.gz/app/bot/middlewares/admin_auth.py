"""
AdminAuthMiddleware.

Applied ONLY to the admin router. Rejects any update from a Telegram user
whose ID is not in Settings.admin_id_set, read from .env (rule #16/#23).
This is the single authorization checkpoint for the entire admin panel —
individual admin handlers do not re-check.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.config import get_settings

logger = logging.getLogger(__name__)


class AdminAuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = data.get("event_from_user")
        settings = get_settings()

        if tg_user is None or tg_user.id not in settings.admin_id_set:
            logger.warning("Unauthorized admin access attempt by telegram_id=%s", getattr(tg_user, "id", None))
            if isinstance(event, CallbackQuery):
                await event.answer("⛔️ دسترسی غیرمجاز", show_alert=True)
            elif isinstance(event, Message):
                await event.answer("⛔️ شما دسترسی ادمین ندارید.")
            return None

        return await handler(event, data)
