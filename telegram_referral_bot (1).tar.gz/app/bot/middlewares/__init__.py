"""Middleware registry."""
from app.bot.middlewares.admin_auth import AdminAuthMiddleware
from app.bot.middlewares.database import DatabaseMiddleware
from app.bot.middlewares.throttling import ThrottlingMiddleware
from app.bot.middlewares.user_context import UserContextMiddleware

__all__ = [
    "DatabaseMiddleware",
    "UserContextMiddleware",
    "ThrottlingMiddleware",
    "AdminAuthMiddleware",
]
