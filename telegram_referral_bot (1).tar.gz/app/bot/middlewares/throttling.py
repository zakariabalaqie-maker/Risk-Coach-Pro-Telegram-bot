"""
ThrottlingMiddleware.

Simple in-memory rate limiter: rejects updates from the same Telegram user
arriving faster than `min_interval` seconds apart. This is intentionally
lightweight (no Redis dependency for the MVP) — acceptable because a single
long-polling process holds this state in memory; if it restarts, worst case
is a brief throttle-reset, not a security hole (real authorization checks
are separate, see admin middleware).
"""
from __future__ import annotations

import time
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, min_interval_seconds: float = 0.5) -> None:
        self.min_interval = min_interval_seconds
        self._last_seen: dict[int, float] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = data.get("event_from_user")
        if tg_user is None:
            return await handler(event, data)

        now = time.monotonic()
        last = self._last_seen.get(tg_user.id)
        self._last_seen[tg_user.id] = now

        if last is not None and (now - last) < self.min_interval:
            # Silently drop callback queries (just ack so the client stops
            # spinning); for messages we stay quiet too, to avoid the bot
            # itself becoming a spam vector under rapid-fire input.
            if isinstance(event, CallbackQuery):
                await event.answer()
            return None

        return await handler(event, data)
