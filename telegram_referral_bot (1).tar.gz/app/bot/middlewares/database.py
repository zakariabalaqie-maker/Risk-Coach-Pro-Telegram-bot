"""
DatabaseMiddleware.

Opens exactly one transactional session per incoming Telegram update and
injects a ready-to-use UnitOfWork into handler data. Commits on clean
handler exit, rolls back on exception (via session_scope), so handlers
never manage transactions themselves.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from app.database.database import session_scope
from app.services import UnitOfWork

logger = logging.getLogger(__name__)


class DatabaseMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        async with session_scope() as session:
            data["uow"] = UnitOfWork(session)
            return await handler(event, data)
