"""
UserContextMiddleware.

Loads (or lazily creates) the `User` row for whoever sent this update, and
injects it into handler data as `db_user`, so handlers never have to repeat
"get or create user" boilerplate. Also enforces the is_blocked flag here,
in one place, rather than scattered per-handler checks.

Must run AFTER DatabaseMiddleware (needs `uow` already in data).
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject, Update

from app.services import UnitOfWork

logger = logging.getLogger(__name__)

_BLOCKED_MESSAGE = "⛔️ دسترسی شما به این ربات محدود شده است."


class UserContextMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = data.get("event_from_user")
        if tg_user is None or tg_user.is_bot:
            return await handler(event, data)

        uow: UnitOfWork = data["uow"]
        db_user = await uow.user_repo.get_by_telegram_id(tg_user.id)

        if db_user is not None:
            # Keep username/name fresh — Telegram profiles change over time
            # and we display these in the admin panel / leaderboard.
            await uow.user_repo.update_profile_fields(
                db_user,
                username=tg_user.username,
                first_name=tg_user.first_name,
                last_name=tg_user.last_name,
            )
            await uow.user_repo.touch_last_active(db_user)

            if db_user.is_blocked:
                await self._notify_blocked(event)
                return None  # short-circuit: blocked users get no further processing

        data["db_user"] = db_user  # may be None for a first-time /start — handler creates it
        return await handler(event, data)

    @staticmethod
    async def _notify_blocked(event: TelegramObject) -> None:
        try:
            if isinstance(event, Update):
                inner = event.message or (event.callback_query.message if event.callback_query else None)
                if isinstance(inner, Message):
                    await inner.answer(_BLOCKED_MESSAGE)
                elif event.callback_query:
                    await event.callback_query.answer(_BLOCKED_MESSAGE, show_alert=True)
            elif isinstance(event, CallbackQuery):
                await event.answer(_BLOCKED_MESSAGE, show_alert=True)
            elif isinstance(event, Message):
                await event.answer(_BLOCKED_MESSAGE)
        except Exception:  # noqa: BLE001
            logger.exception("Failed to notify blocked user")
