"""Persian notification templates for background/event-driven messages (rule #21)."""
from __future__ import annotations


def _progress_bar(current: int, total: int, width: int = 10) -> str:
    current = max(0, min(current, total))
    filled = round((current / total) * width) if total else 0
    return "█" * filled + "░" * (width - filled)


def new_referral_pending(referrer_name: str) -> str:
    return f"👋 {referrer_name} یک کاربر جدید را با لینک شما دعوت کرد. در انتظار عضویت..."


def referral_validated(current: int, required: int) -> str:
    remaining = max(0, required - current)
    bar = _progress_bar(current, required)
    remaining_line = (
        f"فقط {remaining} نفر دیگر تا باز شدن جایزه باقی مانده."
        if remaining > 0
        else "همه شرایط تکمیل شد! 🎉"
    )
    return (
        "🎉 یک Referral جدید معتبر شد!\n\n"
        f"پیشرفت شما:\n\n{bar} {current} / {required}\n\n"
        f"{remaining_line}"
    )


def referral_left_channel() -> str:
    return "⚠️ یکی از کاربران دعوت‌شده شما از کانال خارج شد و ریفرال او دیگر معتبر شمرده نمی‌شود."


def eight_hours_completed_for_invitee() -> str:
    return "⏱️ ۸ ساعت عضویت شما در کانال تکمیل شد. لطفاً فعالیت‌های معاملاتی باقی‌مانده را انجام دهید."


def campaign_completed(reward_title: str) -> str:
    return (
        "🏆 شما ۵ Referral معتبر را تکمیل کردید!\n\n"
        f"جایزه «{reward_title}» اکنون باز شده است. برای دریافت آن به منوی «📊 وضعیت من» بروید."
    )


def reward_unlocked_notification() -> str:
    return "🔓 جایزه شما باز شد! برای دریافت آن به داشبورد مراجعه کنید."
