"""
FSM states.

Kept intentionally minimal: the actual "which question am I on" progress is
NEVER trusted from FSM state alone — it's always re-derived from the
Answer rows already saved in the database (rule #2: nothing important lives
only in client/session state). FSM state here only tracks *which flow* the
user is currently in, so handlers know how to route a plain-text or
callback message; if the bot restarts and FSM storage is memory-based, the
user simply re-enters the flow via the menu and picks up from their saved
answers with no data loss.
"""
from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class ProfileQuestionsFlow(StatesGroup):
    answering = State()


class ActivityQuestionsFlow(StatesGroup):
    answering = State()  # data: {"referral_id": int}


class AdminSettingsFlow(StatesGroup):
    awaiting_value = State()  # data: {"field": str}


class AdminBroadcastFlow(StatesGroup):
    awaiting_message = State()


class AdminUserSearchFlow(StatesGroup):
    awaiting_query = State()
