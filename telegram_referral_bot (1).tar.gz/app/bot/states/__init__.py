"""FSM state groups registry."""
from app.bot.states.flows import (
    AdminBroadcastFlow,
    AdminSettingsFlow,
    AdminUserSearchFlow,
    ActivityQuestionsFlow,
    ProfileQuestionsFlow,
)

__all__ = [
    "ProfileQuestionsFlow",
    "ActivityQuestionsFlow",
    "AdminSettingsFlow",
    "AdminBroadcastFlow",
    "AdminUserSearchFlow",
]
