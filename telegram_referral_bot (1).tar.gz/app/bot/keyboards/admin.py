"""Inline keyboards for the admin panel (rule #16)."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

CB_ADMIN_ROOT = "adm:root"
CB_ADMIN_USERS = "adm:users"
CB_ADMIN_REFERRALS = "adm:referrals"
CB_ADMIN_REWARDS = "adm:rewards"
CB_ADMIN_STATS = "adm:stats"
CB_ADMIN_FRAUD = "adm:fraud"
CB_ADMIN_SETTINGS = "adm:settings"
CB_ADMIN_BROADCAST = "adm:broadcast"

CB_ADMIN_USER_BLOCK = "adm:user:block"
CB_ADMIN_USER_UNBLOCK = "adm:user:unblock"
CB_ADMIN_USER_VIEW_REFERRALS = "adm:user:refs"
CB_ADMIN_USER_VIEW_PROFILE = "adm:user:profile"

CB_ADMIN_REFERRAL_FORCE_VALID = "adm:ref:valid"
CB_ADMIN_REFERRAL_FORCE_INVALID = "adm:ref:invalid"

CB_ADMIN_FRAUD_CONFIRM = "adm:fraud:confirm"
CB_ADMIN_FRAUD_CLEAR = "adm:fraud:clear"

CB_ADMIN_SETTING_EDIT_PREFIX = "adm:set"


def admin_root_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👥 Users", callback_data=CB_ADMIN_USERS)],
            [InlineKeyboardButton(text="🔗 Referrals", callback_data=CB_ADMIN_REFERRALS)],
            [InlineKeyboardButton(text="🎁 Rewards", callback_data=CB_ADMIN_REWARDS)],
            [InlineKeyboardButton(text="📊 Statistics", callback_data=CB_ADMIN_STATS)],
            [InlineKeyboardButton(text="🛡️ Fraud", callback_data=CB_ADMIN_FRAUD)],
            [InlineKeyboardButton(text="⚙️ Campaign Settings", callback_data=CB_ADMIN_SETTINGS)],
            [InlineKeyboardButton(text="📢 Broadcast", callback_data=CB_ADMIN_BROADCAST)],
        ]
    )


def admin_back_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ Back", callback_data=CB_ADMIN_ROOT)]]
    )


def admin_user_actions_keyboard(user_id: int, *, is_blocked: bool) -> InlineKeyboardMarkup:
    block_button = (
        InlineKeyboardButton(text="✅ Unblock", callback_data=f"{CB_ADMIN_USER_UNBLOCK}:{user_id}")
        if is_blocked
        else InlineKeyboardButton(text="🚫 Block", callback_data=f"{CB_ADMIN_USER_BLOCK}:{user_id}")
    )
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👥 Referrals", callback_data=f"{CB_ADMIN_USER_VIEW_REFERRALS}:{user_id}")],
            [InlineKeyboardButton(text="🧠 Profile", callback_data=f"{CB_ADMIN_USER_VIEW_PROFILE}:{user_id}")],
            [block_button],
            [InlineKeyboardButton(text="⬅️ Back", callback_data=CB_ADMIN_USERS)],
        ]
    )


def admin_referral_override_keyboard(referral_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Force VALID", callback_data=f"{CB_ADMIN_REFERRAL_FORCE_VALID}:{referral_id}"
                ),
                InlineKeyboardButton(
                    text="❌ Force INVALID", callback_data=f"{CB_ADMIN_REFERRAL_FORCE_INVALID}:{referral_id}"
                ),
            ],
            [InlineKeyboardButton(text="⬅️ Back", callback_data=CB_ADMIN_REFERRALS)],
        ]
    )


def admin_fraud_flag_keyboard(flag_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Clean", callback_data=f"{CB_ADMIN_FRAUD_CLEAR}:{flag_id}"),
                InlineKeyboardButton(text="🚫 Confirm fraud", callback_data=f"{CB_ADMIN_FRAUD_CONFIRM}:{flag_id}"),
            ],
            [InlineKeyboardButton(text="⬅️ Back", callback_data=CB_ADMIN_FRAUD)],
        ]
    )


def admin_settings_keyboard() -> InlineKeyboardMarkup:
    fields = [
        ("required_referrals", "👥 Required Referrals"),
        ("membership_hours", "⏱️ Membership Hours"),
        ("required_activities", "🧠 Required Activities"),
        ("reward_title", "🎁 Reward Title"),
        ("reward_description", "📝 Reward Description"),
        ("channel_id", "🆔 Channel ID"),
        ("channel_link", "🔗 Channel Link"),
        ("campaign_enabled", "🔌 Toggle Campaign Enabled"),
    ]
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"{CB_ADMIN_SETTING_EDIT_PREFIX}:{key}")]
        for key, label in fields
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Back", callback_data=CB_ADMIN_ROOT)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ Cancel", callback_data=CB_ADMIN_SETTINGS)]]
    )
