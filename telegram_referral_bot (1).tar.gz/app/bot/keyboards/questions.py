"""Inline keyboard for a single question (used by both PROFILE and ACTIVITY question sets)."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.database.models import Question

# callback_data format: "ans:{question_id}:{option_id}"
CB_ANSWER_PREFIX = "ans"


def question_keyboard(question: Question) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=option.label, callback_data=f"{CB_ANSWER_PREFIX}:{question.id}:{option.id}")]
        for option in question.options
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def parse_answer_callback(data: str) -> tuple[int, int]:
    """Returns (question_id, option_id). Raises ValueError on malformed data."""
    parts = data.split(":")
    if len(parts) != 3 or parts[0] != CB_ANSWER_PREFIX:
        raise ValueError(f"Malformed answer callback data: {data!r}")
    return int(parts[1]), int(parts[2])
