"""Inline keyboards for start/menu/membership/navigation screens."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

# --- Callback data prefixes (kept short & namespaced to avoid collisions) ---
CB_START_CAMPAIGN = "start_campaign"
CB_SHOW_RULES = "show_rules"
CB_CHECK_MEMBERSHIP = "check_membership"
CB_BACK_TO_MENU = "back_to_menu"
CB_DASHBOARD = "dashboard"
CB_MY_INVITE_LINK = "my_invite_link"
CB_MY_REFERRALS = "my_referrals"
CB_MY_PROFILE = "my_profile"
CB_LEADERBOARD = "leaderboard"
CB_CLAIM_REWARD = "claim_reward"


def welcome_keyboard(*, show_dashboard: bool = False) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="🚀 شروع کمپین", callback_data=CB_START_CAMPAIGN)]]
    if show_dashboard:
        rows.append([InlineKeyboardButton(text="📊 وضعیت من", callback_data=CB_DASHBOARD)])
    rows.append([InlineKeyboardButton(text="📜 قوانین", callback_data=CB_SHOW_RULES)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def join_channel_keyboard(channel_link: str) -> InlineKeyboardMarkup:
    rows = []
    if channel_link:
        rows.append([InlineKeyboardButton(text="📢 عضویت در کانال", url=channel_link)])
    rows.append([InlineKeyboardButton(text="✅ بررسی عضویت", callback_data=CB_CHECK_MEMBERSHIP)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def dashboard_keyboard(*, reward_unlocked: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if reward_unlocked:
        rows.append([InlineKeyboardButton(text="🎁 دریافت جایزه", callback_data=CB_CLAIM_REWARD)])
    rows.extend(
        [
            [InlineKeyboardButton(text="🔗 لینک دعوت من", callback_data=CB_MY_INVITE_LINK)],
            [InlineKeyboardButton(text="👥 دعوت‌های من", callback_data=CB_MY_REFERRALS)],
            [InlineKeyboardButton(text="🧠 پروفایل من", callback_data=CB_MY_PROFILE)],
            [InlineKeyboardButton(text="🏆 رتبه‌بندی", callback_data=CB_LEADERBOARD)],
            [InlineKeyboardButton(text="📜 قوانین", callback_data=CB_SHOW_RULES)],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_to_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ بازگشت", callback_data=CB_DASHBOARD)]]
    )


def reward_locked_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ بازگشت", callback_data=CB_DASHBOARD)]]
    )


def reward_unlocked_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🎁 دریافت جایزه", callback_data=CB_CLAIM_REWARD)]]
    )
