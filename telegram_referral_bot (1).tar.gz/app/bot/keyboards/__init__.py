"""Keyboard builders registry."""
