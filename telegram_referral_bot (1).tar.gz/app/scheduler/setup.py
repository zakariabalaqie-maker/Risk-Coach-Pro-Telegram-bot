"""APScheduler wiring — registers the periodic referral-reevaluation job."""
from __future__ import annotations

import logging

from aiogram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import get_settings
from app.scheduler.jobs import reevaluate_pending_referrals

logger = logging.getLogger(__name__)


def create_scheduler(bot: Bot) -> AsyncIOScheduler:
    settings = get_settings()
    scheduler = AsyncIOScheduler(timezone="UTC")

    scheduler.add_job(
        reevaluate_pending_referrals,
        trigger="interval",
        seconds=settings.scheduler_interval_seconds,
        args=[bot],
        id="reevaluate_pending_referrals",
        max_instances=1,  # never overlap ticks if one run takes longer than the interval
        coalesce=True,
        misfire_grace_time=60,
    )

    logger.info(
        "Scheduler configured: reevaluate_pending_referrals every %ss", settings.scheduler_interval_seconds
    )
    return scheduler
