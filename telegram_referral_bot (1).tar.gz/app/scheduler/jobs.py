"""
Scheduler jobs.

Rule #12: an APScheduler job periodically re-checks every non-terminal
referral's membership + 8h eligibility server-side, independent of (and as
a safety net for) the reactive chat_member handler. This is what guarantees
correctness even if a chat_member update is ever missed, delayed, or the
bot was offline when it fired — nothing here trusts client state or a
single event delivery.
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter

from app.database.database import session_scope
from app.database.models import ReferralStatus, RewardStatus
from app.services import MembershipService, UnitOfWork

logger = logging.getLogger(__name__)


async def reevaluate_pending_referrals(bot: Bot) -> None:
    """
    Runs on a fixed interval (Settings.scheduler_interval_seconds).

    For every referral not yet in a terminal state (VALID/INVALID/LEFT),
    re-verify membership via getChatMember and advance the state machine
    if conditions are met. Sends progress notifications (rule #21) for any
    transition that happens as a direct result of this job.
    """
    async with session_scope() as session:
        uow = UnitOfWork(session)
        settings = await uow.campaign_settings_service.get()
        if not settings.channel_id:
            logger.debug("Scheduler: no channel_id configured yet, skipping this tick.")
            return

        membership_service = MembershipService(bot, settings.channel_id)

        candidates = await uow.referral_repo.list_pending_membership_recheck()
        # Also pick up anything already past QUESTIONS_PENDING that might be
        # unblocked now (e.g. a fraud flag was cleared by an admin since the
        # last tick).
        stuck_at_questions = await uow.referral_repo.list_by_status(
            [ReferralStatus.QUESTIONS_PENDING], limit=200
        )
        seen_ids = {r.id for r in candidates}
        for r in stuck_at_questions:
            if r.id not in seen_ids:
                candidates.append(r)

        for referral in candidates:
            previous_status = referral.status
            try:
                new_status = await uow.referral_service.evaluate_referral(
                    referral, membership_service=membership_service
                )
            except Exception:  # noqa: BLE001
                logger.exception("Error evaluating referral %s in scheduler tick", referral.id)
                continue

            if new_status == ReferralStatus.VALID and previous_status != ReferralStatus.VALID:
                await _notify_referral_validated(uow, referral.referrer_id, settings, bot)
            elif new_status == ReferralStatus.LEFT and previous_status != ReferralStatus.LEFT:
                await _notify_referral_left(uow, referral.referrer_id, bot)


async def _notify_referral_validated(uow: UnitOfWork, referrer_id: int, settings, bot: Bot) -> None:
    from app.bot.notifications import campaign_completed, referral_validated

    referrer = await uow.user_repo.get_by_id(referrer_id)
    if referrer is None:
        return

    try:
        await bot.send_message(
            referrer.telegram_id,
            referral_validated(referrer.valid_referrals_count, settings.required_referrals),
        )
        if referrer.valid_referrals_count >= settings.required_referrals:
            await bot.send_message(referrer.telegram_id, campaign_completed(settings.reward_title))
    except TelegramForbiddenError:
        logger.info("User %s blocked the bot; skipping notification.", referrer.telegram_id)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to send validation notification to %s", referrer.telegram_id)


async def _notify_referral_left(uow: UnitOfWork, referrer_id: int, bot: Bot) -> None:
    from app.bot.notifications import referral_left_channel

    referrer = await uow.user_repo.get_by_id(referrer_id)
    if referrer is None:
        return
    try:
        await bot.send_message(referrer.telegram_id, referral_left_channel())
    except TelegramForbiddenError:
        logger.info("User %s blocked the bot; skipping notification.", referrer.telegram_id)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to send left-channel notification to %s", referrer.telegram_id)


async def run_broadcast(bot: Bot, text: str) -> tuple[int, int]:
    """
    Sends `text` to every user who has ever started the bot.

    Respects Telegram's rate limits by sending with a small delay and
    honoring TelegramRetryAfter if the API asks us to back off. Returns
    (sent_count, failed_count).
    """
    async with session_scope() as session:
        uow = UnitOfWork(session)
        # Paginate through users in batches to avoid holding a huge result
        # set / long-lived transaction for very large user bases.
        from sqlalchemy import select

        from app.database.models import User

        result = await session.execute(select(User.telegram_id).where(User.has_started_bot.is_(True)))
        telegram_ids = [row[0] for row in result.all()]

    sent = 0
    failed = 0
    for telegram_id in telegram_ids:
        try:
            await bot.send_message(telegram_id, text)
            sent += 1
        except TelegramRetryAfter as exc:
            await asyncio.sleep(exc.retry_after)
            try:
                await bot.send_message(telegram_id, text)
                sent += 1
            except Exception:  # noqa: BLE001
                failed += 1
        except TelegramForbiddenError:
            failed += 1
        except Exception:  # noqa: BLE001
            logger.exception("Broadcast failed for %s", telegram_id)
            failed += 1
        await asyncio.sleep(0.05)  # ~20 msg/sec, safely under Telegram's ~30/sec global limit

    return sent, failed
