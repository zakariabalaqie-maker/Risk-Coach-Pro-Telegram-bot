"""
Application entrypoint.

Runs the bot via long polling (MVP default per rule #23/#27 — no domain or
VPS required). Webhook mode is scaffolded (see Settings.use_webhook) for
future deployment but long polling is what's wired up and tested here.
"""
from __future__ import annotations

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.bot.handlers import all_routers
from app.bot.middlewares import AdminAuthMiddleware, DatabaseMiddleware, ThrottlingMiddleware, UserContextMiddleware
from app.bot.handlers.admin import router as admin_router
from app.config import get_settings
from app.database.database import dispose_engine, init_models, session_scope
from app.scheduler import create_scheduler
from app.services import UnitOfWork


def configure_logging(log_level: str, log_file: str) -> None:
    from pathlib import Path

    Path(log_file).resolve().parent.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )
    # aiogram/apscheduler are chatty at INFO; keep them at WARNING unless debugging.
    logging.getLogger("apscheduler").setLevel(logging.WARNING)


async def seed_defaults() -> None:
    """Idempotent first-run setup: default questions + campaign settings row.
    Safe to call on every startup (rule #2: restart must never lose or duplicate data)."""
    async with session_scope() as session:
        uow = UnitOfWork(session)
        await uow.question_repo.seed_default_questions_if_empty()

        settings = get_settings()
        campaign = await uow.campaign_settings_service.get()
        # Only backfill channel_id/link from .env if the DB doesn't have them
        # yet — once an admin edits them via the panel, .env is no longer
        # authoritative (rule #17: settings live in DB, not source/config).
        updates = {}
        if not campaign.channel_id and settings.default_channel_id:
            updates["channel_id"] = settings.default_channel_id
        if not campaign.channel_link and settings.default_channel_link:
            updates["channel_link"] = settings.default_channel_link
        if updates:
            await uow.campaign_settings_service.update(**updates)


def build_dispatcher() -> Dispatcher:
    dispatcher = Dispatcher()

    # Global middlewares — order matters: DB session first, then user
    # context (needs `uow`), then throttling. Registered for both message
    # and callback_query update types, plus chat_member for the reactive
    # membership handler.
    for observer in (dispatcher.message, dispatcher.callback_query, dispatcher.chat_member):
        observer.middleware(DatabaseMiddleware())
        observer.middleware(UserContextMiddleware())

    dispatcher.message.middleware(ThrottlingMiddleware())

    # Admin router gets an extra authorization gate, scoped to just that router.
    admin_router.message.middleware(AdminAuthMiddleware())
    admin_router.callback_query.middleware(AdminAuthMiddleware())

    for router in all_routers:
        dispatcher.include_router(router)

    return dispatcher


async def run_polling() -> None:
    settings = get_settings()
    configure_logging(settings.log_level, settings.log_file)
    logger = logging.getLogger(__name__)

    logger.info("Starting Telegram Referral Bot (long polling mode)")

    await init_models()
    await seed_defaults()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dispatcher = build_dispatcher()

    scheduler = create_scheduler(bot)
    scheduler.start()

    try:
        me = await bot.get_me()
        logger.info("Bot authenticated as @%s (id=%s)", me.username, me.id)

        # allowed_updates MUST include chat_member for the reactive
        # membership-change handler (app/bot/handlers/chat_member.py) to
        # receive anything — Telegram does not send chat_member updates by
        # default even to admin bots.
        await dispatcher.start_polling(
            bot,
            allowed_updates=["message", "callback_query", "chat_member", "my_chat_member"],
        )
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()
        await dispose_engine()


def main() -> None:
    try:
        asyncio.run(run_polling())
    except (KeyboardInterrupt, SystemExit):
        pass


if __name__ == "__main__":
    main()
