"""
Application configuration.

All secrets and environment-dependent values are loaded from `.env` via
Pydantic Settings. Nothing here should ever be hard-coded in source.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """
    Static/deployment-level settings.

    NOTE: Business-rule values that admins should be able to tune at runtime
    (required_referrals, membership_hours, etc.) are NOT here — they live in
    the `campaign_settings` DB table (see app/database/models/campaign.py)
    and are read through CampaignSettingsService. This file only holds
    values that legitimately require a process restart to change
    (credentials, infra endpoints, logging level).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Telegram ---
    bot_token: str = Field(..., description="Token issued by @BotFather")
    admin_ids: str = Field(
        default="",
        description="Comma-separated Telegram user IDs allowed into the admin panel",
    )

    # --- Channel (bootstrap defaults; overridable later via Campaign Settings) ---
    default_channel_id: str = Field(
        default="",
        description="Channel chat id (e.g. -1001234567890) or @username. "
        "Bot MUST be an admin of this channel.",
    )
    default_channel_link: str = Field(
        default="",
        description="Public invite link shown to users, e.g. https://t.me/your_channel",
    )

    # --- Database ---
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/bot.db",
        description="SQLAlchemy async connection string. "
        "Swap to postgresql+asyncpg://... to migrate later without code changes.",
    )

    # --- Runtime mode ---
    use_webhook: bool = Field(
        default=False,
        description="False => long polling (default, no domain/VPS needed).",
    )
    webhook_base_url: str = Field(default="")
    webhook_path: str = Field(default="/webhook")
    webhook_secret: str = Field(default="")
    web_server_host: str = Field(default="0.0.0.0")
    web_server_port: int = Field(default=8080)

    # --- Scheduler ---
    scheduler_interval_seconds: int = Field(
        default=60,
        description="How often APScheduler re-evaluates pending referrals.",
    )

    # --- Logging ---
    log_level: str = Field(default="INFO")
    log_file: str = Field(default="./data/bot.log")

    @field_validator("bot_token")
    @classmethod
    def _validate_token(cls, v: str) -> str:
        if not v or ":" not in v:
            raise ValueError(
                "BOT_TOKEN missing or malformed. Get one from @BotFather and "
                "put it in your .env file."
            )
        return v

    @property
    def admin_id_set(self) -> set[int]:
        result: set[int] = set()
        for chunk in self.admin_ids.split(","):
            chunk = chunk.strip()
            if chunk:
                try:
                    result.add(int(chunk))
                except ValueError:
                    continue
        return result


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton. Import and call this, don't instantiate Settings() directly."""
    return Settings()
