"""Repository registry — thin data-access layer, no business logic."""
from app.database.repositories.admin_repository import AdminLogRepository, CampaignSettingsRepository
from app.database.repositories.fraud_repository import FraudRepository
from app.database.repositories.profile_repository import ProfileRepository
from app.database.repositories.question_repository import QuestionRepository
from app.database.repositories.referral_repository import ReferralRepository
from app.database.repositories.reward_repository import RewardRepository
from app.database.repositories.user_repository import UserRepository

__all__ = [
    "UserRepository",
    "ReferralRepository",
    "QuestionRepository",
    "ProfileRepository",
    "RewardRepository",
    "FraudRepository",
    "AdminLogRepository",
    "CampaignSettingsRepository",
]
