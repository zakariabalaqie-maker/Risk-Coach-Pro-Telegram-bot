"""Data-access layer for Referral."""
from __future__ import annotations

from datetime import datetime
from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import Referral, ReferralStatus, User


class ReferralRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, referral_id: int) -> Optional[Referral]:
        result = await self.session.execute(select(Referral).where(Referral.id == referral_id))
        return result.scalar_one_or_none()

    async def get_by_referred_user_id(self, referred_user_id: int) -> Optional[Referral]:
        result = await self.session.execute(
            select(Referral).where(Referral.referred_user_id == referred_user_id)
        )
        return result.scalar_one_or_none()

    async def create(self, *, referrer_id: int, referred_user_id: int) -> Referral:
        referral = Referral(
            referrer_id=referrer_id,
            referred_user_id=referred_user_id,
            status=ReferralStatus.PENDING,
        )
        self.session.add(referral)
        await self.session.flush()
        return referral

    async def list_by_referrer(
        self, referrer_id: int, *, with_referred_user: bool = True
    ) -> Sequence[Referral]:
        stmt = select(Referral).where(Referral.referrer_id == referrer_id).order_by(Referral.created_at.desc())
        if with_referred_user:
            stmt = stmt.options(selectinload(Referral.referred_user))
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def count_by_referrer_and_status(self, referrer_id: int, statuses: Sequence[ReferralStatus]) -> int:
        stmt = (
            select(func.count())
            .select_from(Referral)
            .where(Referral.referrer_id == referrer_id, Referral.status.in_(statuses))
        )
        result = await self.session.execute(stmt)
        return int(result.scalar_one())

    async def list_awaiting_eligibility(self, *, now: datetime) -> Sequence[Referral]:
        """Referrals whose 8h window has elapsed but haven't been evaluated yet.
        Used by the scheduler (rule #12)."""
        stmt = (
            select(Referral)
            .where(
                Referral.status.in_([ReferralStatus.JOINED, ReferralStatus.WAITING_8_HOURS]),
                Referral.eligible_at.is_not(None),
                Referral.eligible_at <= now,
            )
            .options(selectinload(Referral.referred_user), selectinload(Referral.referrer))
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def list_pending_membership_recheck(self) -> Sequence[Referral]:
        """Referrals still waiting on their 8h window — periodically re-verified
        for membership as a safety net alongside live chat_member events."""
        stmt = (
            select(Referral)
            .where(Referral.status.in_([ReferralStatus.JOINED, ReferralStatus.WAITING_8_HOURS]))
            .options(selectinload(Referral.referred_user), selectinload(Referral.referrer))
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def list_by_status(self, statuses: Sequence[ReferralStatus], limit: int = 50) -> Sequence[Referral]:
        stmt = (
            select(Referral)
            .where(Referral.status.in_(statuses))
            .order_by(Referral.created_at.desc())
            .limit(limit)
            .options(selectinload(Referral.referrer), selectinload(Referral.referred_user))
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def count_by_status(self, statuses: Sequence[ReferralStatus]) -> int:
        stmt = select(func.count()).select_from(Referral).where(Referral.status.in_(statuses))
        result = await self.session.execute(stmt)
        return int(result.scalar_one())

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count()).select_from(Referral))
        return int(result.scalar_one())
