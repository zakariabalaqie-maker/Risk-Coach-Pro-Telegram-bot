"""Data-access layer for Question / QuestionOption / Answer."""
from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import Answer, Question, QuestionOption, QuestionSet


class QuestionRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_active(self, question_set: QuestionSet) -> Sequence[Question]:
        stmt = (
            select(Question)
            .where(Question.question_set == question_set, Question.is_active.is_(True))
            .order_by(Question.order_index.asc())
            .options(selectinload(Question.options))
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def get_by_id(self, question_id: int) -> Optional[Question]:
        stmt = select(Question).where(Question.id == question_id).options(selectinload(Question.options))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_option(self, option_id: int) -> Optional[QuestionOption]:
        result = await self.session.execute(select(QuestionOption).where(QuestionOption.id == option_id))
        return result.scalar_one_or_none()

    async def get_answer(
        self, *, user_id: int, question_id: int, referral_id: Optional[int]
    ) -> Optional[Answer]:
        stmt = select(Answer).where(
            Answer.user_id == user_id,
            Answer.question_id == question_id,
            Answer.referral_id == referral_id,
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def upsert_answer(
        self, *, user_id: int, question_id: int, option_id: int, referral_id: Optional[int]
    ) -> Answer:
        existing = await self.get_answer(user_id=user_id, question_id=question_id, referral_id=referral_id)
        if existing:
            existing.option_id = option_id
            await self.session.flush()
            return existing
        answer = Answer(
            user_id=user_id, question_id=question_id, option_id=option_id, referral_id=referral_id
        )
        self.session.add(answer)
        await self.session.flush()
        return answer

    async def list_answers_for_user(
        self, *, user_id: int, question_set: QuestionSet, referral_id: Optional[int] = None
    ) -> Sequence[Answer]:
        stmt = (
            select(Answer)
            .join(Question, Answer.question_id == Question.id)
            .where(Answer.user_id == user_id, Question.question_set == question_set)
            .options(selectinload(Answer.option), selectinload(Answer.question))
        )
        if question_set == QuestionSet.ACTIVITY:
            stmt = stmt.where(Answer.referral_id == referral_id)
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def seed_default_questions_if_empty(self) -> None:
        """Populate the two DB-managed question sets on first run only.
        Never overwrites existing questions (admin edits must survive restarts)."""
        existing = await self.session.execute(select(Question.id).limit(1))
        if existing.first() is not None:
            return

        profile_questions = [
            (
                "چند وقت است ترید می‌کنید؟",
                "experience",
                [
                    ("کمتر از ۳ ماه", 10),
                    ("۳ تا ۱۲ ماه", 30),
                    ("۱ تا ۳ سال", 60),
                    ("بیشتر از ۳ سال", 90),
                    ("هنوز شروع نکرده‌ام", 5),
                ],
            ),
            (
                "بیشتر در کدام بازار فعالیت می‌کنید؟",
                "market",
                [
                    ("Forex", 0),
                    ("Gold / XAUUSD", 0),
                    ("Crypto", 0),
                    ("Indices", 0),
                    ("Stocks", 0),
                    ("Other", 0),
                ],
            ),
            (
                "بزرگ‌ترین مشکل شما چیست؟",
                "challenge",
                [
                    ("Risk Management", 0),
                    ("Emotional Control", 0),
                    ("Consecutive Losses", 0),
                    ("Entry / Exit", 0),
                    ("Discipline", 0),
                    ("Strategy", 0),
                ],
            ),
            (
                "معمولاً در هر معامله چقدر ریسک می‌کنید؟",
                "risk_pct",
                [
                    ("کمتر از ۰.۵٪", 90),
                    ("۰.۵ تا ۱٪", 75),
                    ("۱ تا ۲٪", 55),
                    ("بیشتر از ۲٪", 20),
                    ("نمی‌دانم", 10),
                ],
            ),
            (
                "قبل از باز کردن معامله کدام ابزار بیشتر برای شما مفید است؟",
                "tool_pref",
                [
                    ("Risk Analysis", 80),
                    ("Position Size", 70),
                    ("Drawdown Protection", 70),
                    ("Trade Management", 60),
                    ("Discipline", 50),
                    ("None", 10),
                ],
            ),
        ]

        activity_questions = [
            (
                "امروز چند ساعت روی چارت وقت گذاشتید؟",
                [
                    ("کمتر از ۱ ساعت", 0),
                    ("۱ تا ۳ ساعت", 0),
                    ("بیشتر از ۳ ساعت", 0),
                ],
            ),
            (
                "آخرین معامله شما سود بود یا ضرر؟",
                [
                    ("سود", 0),
                    ("ضرر", 0),
                    ("هنوز معامله نکرده‌ام", 0),
                ],
            ),
            (
                "قبل از ورود به معامله حد ضرر تعیین می‌کنید؟",
                [
                    ("همیشه", 0),
                    ("گاهی", 0),
                    ("هرگز", 0),
                ],
            ),
            (
                "بیشترین ریسک قابل قبول شما در یک روز چند درصد است؟",
                [
                    ("کمتر از ۲٪", 0),
                    ("۲ تا ۵٪", 0),
                    ("بیشتر از ۵٪", 0),
                ],
            ),
            (
                "از کدام سبک معاملاتی بیشتر استفاده می‌کنید؟",
                [
                    ("اسکالپینگ", 0),
                    ("دی‌تریدینگ", 0),
                    ("سوئینگ", 0),
                    ("پوزیشن بلندمدت", 0),
                ],
            ),
        ]

        for order_index, (text, dimension_key, options) in enumerate(profile_questions, start=1):
            question = Question(
                question_set=QuestionSet.PROFILE,
                order_index=order_index,
                text=text,
                dimension_key=dimension_key,
            )
            self.session.add(question)
            await self.session.flush()
            for opt_index, (label, weight) in enumerate(options, start=1):
                self.session.add(
                    QuestionOption(
                        question_id=question.id,
                        order_index=opt_index,
                        label=label,
                        score_weight=weight,
                    )
                )

        for order_index, (text, options) in enumerate(activity_questions, start=1):
            question = Question(
                question_set=QuestionSet.ACTIVITY,
                order_index=order_index,
                text=text,
                dimension_key=None,
            )
            self.session.add(question)
            await self.session.flush()
            for opt_index, (label, weight) in enumerate(options, start=1):
                self.session.add(
                    QuestionOption(
                        question_id=question.id,
                        order_index=opt_index,
                        label=label,
                        score_weight=weight,
                    )
                )

        await self.session.flush()
