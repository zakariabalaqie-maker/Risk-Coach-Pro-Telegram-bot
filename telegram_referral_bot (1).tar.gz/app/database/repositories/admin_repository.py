"""Data-access layer for AdminLog and CampaignSettings."""
from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import DEFAULT_CAMPAIGN_KEY, AdminLog, CampaignSettings


class AdminLogRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def log(
        self,
        *,
        admin_telegram_id: int,
        admin_user_id: Optional[int],
        action: str,
        target_type: Optional[str] = None,
        target_id: Optional[int] = None,
        detail: Optional[str] = None,
    ) -> AdminLog:
        entry = AdminLog(
            admin_telegram_id=admin_telegram_id,
            admin_user_id=admin_user_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            detail=detail,
        )
        self.session.add(entry)
        await self.session.flush()
        return entry

    async def recent(self, limit: int = 20) -> Sequence[AdminLog]:
        stmt = select(AdminLog).order_by(AdminLog.created_at.desc()).limit(limit)
        result = await self.session.execute(stmt)
        return result.scalars().all()


class CampaignSettingsRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self) -> CampaignSettings:
        result = await self.session.execute(
            select(CampaignSettings).where(CampaignSettings.key == DEFAULT_CAMPAIGN_KEY)
        )
        settings = result.scalar_one_or_none()
        if settings is None:
            settings = CampaignSettings(key=DEFAULT_CAMPAIGN_KEY)
            self.session.add(settings)
            await self.session.flush()
        return settings

    async def update(self, **kwargs) -> CampaignSettings:
        settings = await self.get()
        for key, value in kwargs.items():
            if value is not None and hasattr(settings, key):
                setattr(settings, key, value)
        await self.session.flush()
        return settings
