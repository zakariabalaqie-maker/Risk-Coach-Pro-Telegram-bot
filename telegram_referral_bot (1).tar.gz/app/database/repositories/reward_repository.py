"""
Data-access layer for Reward.

The compare-and-swap update methods here (`try_unlock`, `try_claim`) are
what makes reward granting/claiming idempotent (rule #15) — they update
only if the current status matches what's expected, and report back
whether the transition actually happened, so the service layer can never
double-grant or double-claim even under concurrent calls.
"""
from __future__ import annotations

from typing import Optional

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Reward, RewardStatus, utcnow


class RewardRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_user_id(self, user_id: int) -> Optional[Reward]:
        result = await self.session.execute(select(Reward).where(Reward.user_id == user_id))
        return result.scalar_one_or_none()

    async def get_or_create(self, user_id: int) -> Reward:
        reward = await self.get_by_user_id(user_id)
        if reward is None:
            reward = Reward(user_id=user_id, status=RewardStatus.LOCKED)
            self.session.add(reward)
            await self.session.flush()
        return reward

    async def try_unlock(self, user_id: int, *, title: str, description: str) -> bool:
        """Atomically LOCKED -> UNLOCKED. Returns True iff this call performed the transition."""
        result = await self.session.execute(
            update(Reward)
            .where(Reward.user_id == user_id, Reward.status == RewardStatus.LOCKED)
            .values(
                status=RewardStatus.UNLOCKED,
                unlocked_at=utcnow(),
                reward_title_snapshot=title,
                reward_description_snapshot=description,
            )
        )
        return result.rowcount > 0

    async def try_claim(self, user_id: int) -> bool:
        """Atomically UNLOCKED -> CLAIMED. Returns True iff this call performed the transition.
        A second, concurrent, or repeated call will see rowcount == 0 and return False —
        this IS the idempotency guarantee required by rule #15."""
        result = await self.session.execute(
            update(Reward)
            .where(Reward.user_id == user_id, Reward.status == RewardStatus.UNLOCKED)
            .values(status=RewardStatus.CLAIMED, claimed_at=utcnow())
        )
        return result.rowcount > 0

    async def count_by_status(self, status: RewardStatus) -> int:
        result = await self.session.execute(
            select(func.count()).select_from(Reward).where(Reward.status == status)
        )
        return int(result.scalar_one())
