"""Data-access layer for User. No business logic here — just queries."""
from __future__ import annotations

import secrets
import string
from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import MembershipStatus, User, utcnow

REFERRAL_CODE_ALPHABET = string.ascii_uppercase + string.digits


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, user_id: int, *, with_profile: bool = False) -> Optional[User]:
        stmt = select(User).where(User.id == user_id)
        if with_profile:
            stmt = stmt.options(selectinload(User.profile), selectinload(User.reward))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(select(User).where(User.telegram_id == telegram_id))
        return result.scalar_one_or_none()

    async def get_by_referral_code(self, code: str) -> Optional[User]:
        result = await self.session.execute(select(User).where(User.referral_code == code))
        return result.scalar_one_or_none()

    async def search_by_username_or_id(self, query: str, limit: int = 10) -> Sequence[User]:
        query = query.strip().lstrip("@")
        stmt = select(User).limit(limit)
        if query.isdigit():
            stmt = stmt.where(User.telegram_id == int(query))
        else:
            stmt = stmt.where(User.username.ilike(f"%{query}%"))
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def generate_unique_referral_code(self) -> str:
        """Loop until we find a code with no collision. Space is 36^8, collisions are practically nil,
        but we still verify against the DB defensively rather than assume."""
        for _ in range(20):
            code = "REF" + "".join(secrets.choice(REFERRAL_CODE_ALPHABET) for _ in range(8))
            existing = await self.get_by_referral_code(code)
            if existing is None:
                return code
        raise RuntimeError("Could not generate a unique referral code after 20 attempts")

    async def create_user(
        self,
        *,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        language_code: Optional[str],
    ) -> User:
        code = await self.generate_unique_referral_code()
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            language_code=language_code,
            referral_code=code,
        )
        self.session.add(user)
        await self.session.flush()
        return user

    async def touch_last_active(self, user: User) -> None:
        user.last_active_at = utcnow()

    async def update_profile_fields(
        self,
        user: User,
        *,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
    ) -> None:
        user.username = username
        user.first_name = first_name
        user.last_name = last_name

    async def set_membership_status(
        self, user: User, status: MembershipStatus, *, at=None
    ) -> None:
        at = at or utcnow()
        user.membership_status = status
        user.last_membership_check_at = at
        if status == MembershipStatus.MEMBER and user.joined_channel_at is None:
            user.joined_channel_at = at
        if status in (MembershipStatus.LEFT, MembershipStatus.KICKED):
            user.left_channel_at = at

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count()).select_from(User))
        return int(result.scalar_one())

    async def count_active_since(self, since) -> int:
        result = await self.session.execute(
            select(func.count()).select_from(User).where(User.last_active_at >= since)
        )
        return int(result.scalar_one())

    async def count_blocked(self) -> int:
        result = await self.session.execute(
            select(func.count()).select_from(User).where(User.is_blocked.is_(True))
        )
        return int(result.scalar_one())

    async def leaderboard(self, limit: int = 10) -> Sequence[User]:
        stmt = (
            select(User)
            .where(User.valid_referrals_count > 0)
            .order_by(User.valid_referrals_count.desc(), User.id.asc())
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def rank_of(self, user: User) -> int:
        """1-indexed rank by valid_referrals_count, ties broken by earlier id (fair + deterministic)."""
        stmt = select(func.count()).select_from(User).where(
            (User.valid_referrals_count > user.valid_referrals_count)
            | (
                (User.valid_referrals_count == user.valid_referrals_count)
                & (User.id < user.id)
            )
        )
        result = await self.session.execute(stmt)
        return int(result.scalar_one()) + 1
