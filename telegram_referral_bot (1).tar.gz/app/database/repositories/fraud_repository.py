"""Data-access layer for FraudFlag."""
from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import FraudFlag, FraudFlagStatus, FraudFlagType, utcnow


class FraudRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create_flag(
        self,
        *,
        user_id: int,
        flag_type: FraudFlagType,
        detail: Optional[str] = None,
        referral_id: Optional[int] = None,
    ) -> FraudFlag:
        flag = FraudFlag(user_id=user_id, referral_id=referral_id, flag_type=flag_type, detail=detail)
        self.session.add(flag)
        await self.session.flush()
        return flag

    async def list_open_for_user(self, user_id: int) -> Sequence[FraudFlag]:
        stmt = select(FraudFlag).where(
            FraudFlag.user_id == user_id, FraudFlag.status == FraudFlagStatus.OPEN
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def list_open(self, limit: int = 50) -> Sequence[FraudFlag]:
        stmt = (
            select(FraudFlag)
            .where(FraudFlag.status == FraudFlagStatus.OPEN)
            .order_by(FraudFlag.created_at.desc())
            .limit(limit)
            .options(selectinload(FraudFlag.user))
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def get_by_id(self, flag_id: int) -> Optional[FraudFlag]:
        result = await self.session.execute(select(FraudFlag).where(FraudFlag.id == flag_id))
        return result.scalar_one_or_none()

    async def review(self, flag: FraudFlag, *, admin_id: int, confirmed: bool) -> None:
        flag.status = FraudFlagStatus.REVIEWED_CONFIRMED if confirmed else FraudFlagStatus.REVIEWED_CLEAN
        flag.reviewed_by_admin_id = admin_id
        flag.reviewed_at = utcnow()
