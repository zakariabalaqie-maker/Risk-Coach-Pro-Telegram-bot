"""Data-access layer for TraderProfile."""
from __future__ import annotations

from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import TraderProfile


class ProfileRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_user_id(self, user_id: int) -> Optional[TraderProfile]:
        result = await self.session.execute(select(TraderProfile).where(TraderProfile.user_id == user_id))
        return result.scalar_one_or_none()

    async def upsert(
        self,
        *,
        user_id: int,
        experience_label: str,
        primary_market_label: str,
        main_challenge_label: str,
        typical_risk_label: str,
        preferred_tool_label: str,
        risk_awareness_score: int,
    ) -> TraderProfile:
        profile = await self.get_by_user_id(user_id)
        if profile is None:
            profile = TraderProfile(user_id=user_id)
            self.session.add(profile)

        profile.experience_label = experience_label
        profile.primary_market_label = primary_market_label
        profile.main_challenge_label = main_challenge_label
        profile.typical_risk_label = typical_risk_label
        profile.preferred_tool_label = preferred_tool_label
        profile.risk_awareness_score = risk_awareness_score

        await self.session.flush()
        return profile
