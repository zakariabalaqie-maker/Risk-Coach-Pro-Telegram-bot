"""
Async SQLAlchemy engine + session factory.

Everything here is written against the async SQLAlchemy API so that
switching DATABASE_URL from `sqlite+aiosqlite:///...` to
`postgresql+asyncpg://...` later requires ZERO changes to this file or to
any repository/service — only the .env value and (for SQLite-specific
pragmas below) a short-circuit that already checks the dialect name.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from app.config import get_settings
from app.database.models import Base

logger = logging.getLogger(__name__)

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def _ensure_sqlite_dir(database_url: str) -> None:
    """SQLite needs its parent directory to exist before connecting."""
    if "sqlite" not in database_url:
        return
    # sqlite+aiosqlite:///./data/bot.db -> ./data/bot.db
    path_part = database_url.split("///", maxsplit=1)[-1]
    if path_part and path_part != ":memory:":
        Path(path_part).resolve().parent.mkdir(parents=True, exist_ok=True)


def get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        settings = get_settings()
        _ensure_sqlite_dir(settings.database_url)

        connect_args: dict = {}
        engine_kwargs: dict = {}
        is_sqlite = "sqlite" in settings.database_url

        if is_sqlite:
            connect_args["check_same_thread"] = False
            if ":memory:" in settings.database_url:
                # Used by the test-suite: keep a single in-memory DB alive
                # across connections for the lifetime of the engine.
                engine_kwargs["poolclass"] = StaticPool

        _engine = create_async_engine(
            settings.database_url,
            echo=False,
            future=True,
            connect_args=connect_args,
            **engine_kwargs,
        )

        if is_sqlite:
            # Enable WAL + foreign keys for SQLite. WAL specifically matters
            # here: it lets the scheduler (writer) and bot handlers (readers/
            # writers) hit the same file concurrently without "database is
            # locked" errors, which is the most common SQLite+asyncio pitfall.
            @event.listens_for(_engine.sync_engine, "connect")
            def _set_sqlite_pragma(dbapi_connection, connection_record):  # noqa: ANN001
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA busy_timeout=5000")
                cursor.close()

    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            bind=get_engine(), expire_on_commit=False, class_=AsyncSession
        )
    return _session_factory


@asynccontextmanager
async def session_scope() -> AsyncIterator[AsyncSession]:
    """
    Provide a transactional scope. Commits on clean exit, rolls back on
    exception, always closes. This is the ONLY way the rest of the app
    should obtain a session — never instantiate AsyncSession directly.
    """
    session_factory = get_session_factory()
    session = session_factory()
    try:
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        await session.close()


async def init_models() -> None:
    """
    Create all tables if they don't exist yet (SQLite MVP path).

    This is intentionally idempotent and non-destructive: it never drops or
    alters existing tables, so re-running it on every startup is safe and
    satisfies the "never lose data / never rebuild from scratch" rule. When
    the project migrates to PostgreSQL, this call should be replaced by
    `alembic upgrade head` (see migrations/ and README section on Postgres
    migration) — the ORM models themselves do not change.
    """
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables ensured (create_all, non-destructive).")


async def dispose_engine() -> None:
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
    _engine = None
    _session_factory = None
