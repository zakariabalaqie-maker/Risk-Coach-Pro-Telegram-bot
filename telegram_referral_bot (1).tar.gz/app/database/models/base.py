"""Declarative base + shared enums for all ORM models."""
from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import DateTime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    """Single source of truth for 'server time'. Always timezone-aware UTC.

    Per project rule #12: all eligibility timestamps must come from the
    server, never trust a client-supplied time.
    """
    return datetime.now(timezone.utc)


def as_aware_utc(value: datetime) -> datetime:
    """
    Normalize a datetime that MAY have come back naive from the DB driver
    into a timezone-aware UTC datetime.

    SQLite (via aiosqlite) does not preserve tzinfo on round-trip even
    though we always write timezone-aware values — it stores/reads them as
    naive strings. PostgreSQL (asyncpg), by contrast, DOES round-trip
    tzinfo correctly for TIMESTAMPTZ columns. This helper makes comparisons
    safe on both backends: naive values are assumed to already be UTC
    (true for everything this app ever writes, since utcnow() is the only
    writer), and already-aware values pass through unchanged.
    """
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


class Base(DeclarativeBase):
    """Shared declarative base for every model in the app."""
    pass


class TimestampMixin:
    """created_at / updated_at columns, always server-side."""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )


class MembershipStatus(str, enum.Enum):
    UNKNOWN = "UNKNOWN"
    MEMBER = "MEMBER"
    LEFT = "LEFT"
    KICKED = "KICKED"


class ReferralStatus(str, enum.Enum):
    """State machine per project rule #11.

    PENDING -> JOINED -> WAITING_8_HOURS -> QUESTIONS_PENDING -> VALID
    Any state can transition to LEFT (user left channel) or INVALID (fraud).
    """

    PENDING = "PENDING"
    JOINED = "JOINED"
    WAITING_8_HOURS = "WAITING_8_HOURS"
    QUESTIONS_PENDING = "QUESTIONS_PENDING"
    VALID = "VALID"
    LEFT = "LEFT"
    INVALID = "INVALID"


class RewardStatus(str, enum.Enum):
    LOCKED = "LOCKED"
    UNLOCKED = "UNLOCKED"
    CLAIMED = "CLAIMED"


class FraudFlagType(str, enum.Enum):
    SELF_REFERRAL_ATTEMPT = "SELF_REFERRAL_ATTEMPT"
    DUPLICATE_TELEGRAM_ID = "DUPLICATE_TELEGRAM_ID"
    DUPLICATE_REFERRAL = "DUPLICATE_REFERRAL"
    EXISTING_USER_ATTRIBUTION = "EXISTING_USER_ATTRIBUTION"
    MULTIPLE_REWARD_CLAIM_ATTEMPT = "MULTIPLE_REWARD_CLAIM_ATTEMPT"
    SUSPICIOUS_PATTERN = "SUSPICIOUS_PATTERN"
    RAPID_ACCOUNT_CREATION = "RAPID_ACCOUNT_CREATION"
    MANUAL_ADMIN_FLAG = "MANUAL_ADMIN_FLAG"


class FraudFlagStatus(str, enum.Enum):
    OPEN = "OPEN"
    REVIEWED_CLEAN = "REVIEWED_CLEAN"
    REVIEWED_CONFIRMED = "REVIEWED_CONFIRMED"
