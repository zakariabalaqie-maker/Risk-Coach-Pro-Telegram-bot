"""AdminLog — audit trail of every admin action (rule #18)."""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class AdminLog(TimestampMixin, Base):
    __tablename__ = "admin_logs"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    admin_user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    admin_telegram_id: Mapped[int] = mapped_column(nullable=False)

    action: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    target_type: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    target_id: Mapped[Optional[int]] = mapped_column(nullable=True)
    detail: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    admin_user: Mapped[Optional["User"]] = relationship(
        "User", back_populates="admin_actions", foreign_keys=[admin_user_id]
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AdminLog action={self.action} admin={self.admin_telegram_id}>"
