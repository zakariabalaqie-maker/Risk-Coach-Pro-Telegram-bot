"""
CampaignSettings — singleton row holding all admin-tunable campaign
parameters (rule #17). Read through CampaignSettingsService, which caches
briefly and invalidates on admin writes.

Designed as a single-row table today; the `key` primary key (fixed to
"default") is intentional groundwork for rule #29's future "multiple
campaigns" feature — at that point this becomes a proper multi-row table
keyed by campaign slug instead of a schema rewrite.
"""
from __future__ import annotations

from sqlalchemy import Boolean, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database.models.base import Base, TimestampMixin

DEFAULT_CAMPAIGN_KEY = "default"


class CampaignSettings(TimestampMixin, Base):
    __tablename__ = "campaign_settings"

    key: Mapped[str] = mapped_column(String(32), primary_key=True, default=DEFAULT_CAMPAIGN_KEY)

    campaign_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    required_referrals: Mapped[int] = mapped_column(Integer, default=5, nullable=False)
    membership_hours: Mapped[int] = mapped_column(Integer, default=8, nullable=False)
    required_activities: Mapped[int] = mapped_column(Integer, default=5, nullable=False)

    reward_title: Mapped[str] = mapped_column(String(128), default="Expert Advisor معاملاتی", nullable=False)
    reward_description: Mapped[str] = mapped_column(
        Text,
        default="یک اکسپرت معاملاتی حرفه‌ای با ارزش تجاری اعلام‌شده $2,000",
        nullable=False,
    )

    channel_id: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    channel_link: Mapped[str] = mapped_column(String(255), default="", nullable=False)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<CampaignSettings enabled={self.campaign_enabled} required_referrals={self.required_referrals}>"
