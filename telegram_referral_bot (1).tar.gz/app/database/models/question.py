"""
Question / Option / Answer models.

Rule #17 requires that questions & options be manageable from the database
(via the admin panel), not hard-coded in Python. Two question sets exist,
distinguished by `QuestionSet`:

  PROFILE   -> the initial 5-question trader profile (rule #8)
  ACTIVITY  -> the 5 short "activity" questions each invited referral must
               answer (rule #13)

Both reuse the same schema since they're structurally identical
(single-select inline-keyboard questions with weighted options).
"""
from __future__ import annotations

import enum
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class QuestionSet(str, enum.Enum):
    PROFILE = "PROFILE"
    ACTIVITY = "ACTIVITY"


class Question(TimestampMixin, Base):
    __tablename__ = "questions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    question_set: Mapped[QuestionSet] = mapped_column(nullable=False, index=True)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    # Which trader-profile "dimension" this question scores, e.g.
    # "experience", "market", "challenge", "risk_pct", "tool_pref".
    # Only meaningful for QuestionSet.PROFILE; null/ignored for ACTIVITY.
    dimension_key: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    options: Mapped[list["QuestionOption"]] = relationship(
        "QuestionOption",
        back_populates="question",
        cascade="all, delete-orphan",
        order_by="QuestionOption.order_index",
    )

    __table_args__ = (
        UniqueConstraint("question_set", "order_index", name="uq_question_set_order"),
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Question id={self.id} set={self.question_set} order={self.order_index}>"


class QuestionOption(TimestampMixin, Base):
    __tablename__ = "question_options"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    question_id: Mapped[int] = mapped_column(
        ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True
    )
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    label: Mapped[str] = mapped_column(String(128), nullable=False)
    # Deterministic score weight (0-100) used for Risk Awareness computation
    # (rule #9). Ignored for ACTIVITY-set questions.
    score_weight: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    question: Mapped["Question"] = relationship("Question", back_populates="options")

    __table_args__ = (
        UniqueConstraint("question_id", "order_index", name="uq_option_question_order"),
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<QuestionOption id={self.id} q={self.question_id} label={self.label!r}>"


class Answer(TimestampMixin, Base):
    """A user's answer to a question, in either question set."""

    __tablename__ = "answers"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    question_id: Mapped[int] = mapped_column(
        ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True
    )
    option_id: Mapped[int] = mapped_column(
        ForeignKey("question_options.id", ondelete="CASCADE"), nullable=False
    )
    # For ACTIVITY-set answers, which referral this answer counts toward.
    # Null for PROFILE-set answers (those belong to the user's own profile).
    referral_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("referrals.id", ondelete="CASCADE"), nullable=True, index=True
    )

    user: Mapped["User"] = relationship("User")
    question: Mapped["Question"] = relationship("Question")
    option: Mapped["QuestionOption"] = relationship("QuestionOption")

    __table_args__ = (
        UniqueConstraint(
            "user_id", "question_id", "referral_id", name="uq_answer_user_question_referral"
        ),
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Answer user={self.user_id} q={self.question_id} opt={self.option_id}>"
