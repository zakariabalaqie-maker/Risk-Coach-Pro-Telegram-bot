"""
Referral model.

One row per (referrer -> referred_user) edge. This is the single
source of truth for the state machine described in project rule #11.
The `users.valid_referrals_count` counter is a cache derived FROM this
table, never the other way around.
"""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, ReferralStatus, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class Referral(TimestampMixin, Base):
    __tablename__ = "referrals"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    referrer_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    referred_user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True
    )

    status: Mapped[ReferralStatus] = mapped_column(default=ReferralStatus.PENDING, nullable=False, index=True)

    # Timestamps for each transition — kept explicitly (not just updated_at)
    # so admins/analytics can reconstruct the full timeline.
    joined_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    eligible_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, comment="joined_at + membership_hours, computed server-side"
    )
    questions_completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    left_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    invalidated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    invalidated_reason: Mapped[Optional[str]] = mapped_column(nullable=True)

    activities_completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    activities_progress: Mapped[int] = mapped_column(default=0, nullable=False)

    # Snapshot of fraud verdict at validation time (denormalized read of
    # FraudFlag table state, recomputed by FraudService before validation).
    fraud_status_clean: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    # Manual admin override (rule #18: admin can force VALID/INVALID).
    manually_overridden: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    overridden_by_admin_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    referrer: Mapped["User"] = relationship(
        "User", back_populates="referrals_made", foreign_keys=[referrer_id]
    )
    referred_user: Mapped["User"] = relationship(
        "User", back_populates="referral_received", foreign_keys=[referred_user_id]
    )

    __table_args__ = (
        UniqueConstraint("referred_user_id", name="uq_referral_one_per_referred_user"),
        Index("ix_referrals_referrer_status", "referrer_id", "status"),
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Referral id={self.id} referrer={self.referrer_id} referred={self.referred_user_id} status={self.status}>"
