"""
Reward model.

Rule #15 requires idempotent claiming: a user must never be able to claim
twice. We enforce this at three layers:
  1. `user_id` is UNIQUE (one reward row per user, ever).
  2. `status` transitions LOCKED -> UNLOCKED -> CLAIMED are guarded by a
     DB-level check in RewardService using SELECT ... then an atomic
     UPDATE ... WHERE status = 'UNLOCKED' (compare-and-swap pattern).
  3. `claimed_at` being non-null is the final, unambiguous idempotency guard.
"""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, RewardStatus, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class Reward(TimestampMixin, Base):
    __tablename__ = "rewards"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
    )
    status: Mapped[RewardStatus] = mapped_column(default=RewardStatus.LOCKED, nullable=False, index=True)

    unlocked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    claimed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Snapshot of what was granted, so changing CampaignSettings later
    # doesn't retroactively alter what an already-rewarded user sees.
    reward_title_snapshot: Mapped[Optional[str]] = mapped_column(nullable=True)
    reward_description_snapshot: Mapped[Optional[str]] = mapped_column(nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="reward")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Reward user={self.user_id} status={self.status}>"
