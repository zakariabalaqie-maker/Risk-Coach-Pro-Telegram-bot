"""
FraudFlag model.

Per rule #19: the system flags suspicious activity for admin review rather
than auto-condemning users when evidence is inconclusive. A referral can
still validate while flags are OPEN if the flag type is informational only;
FraudService decides which flag types block validation (see
app/services/fraud_service.py::BLOCKING_FLAG_TYPES).
"""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, FraudFlagStatus, FraudFlagType, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class FraudFlag(TimestampMixin, Base):
    __tablename__ = "fraud_flags"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    referral_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("referrals.id", ondelete="CASCADE"), nullable=True, index=True
    )

    flag_type: Mapped[FraudFlagType] = mapped_column(nullable=False, index=True)
    status: Mapped[FraudFlagStatus] = mapped_column(default=FraudFlagStatus.OPEN, nullable=False, index=True)
    detail: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    reviewed_by_admin_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship("User", foreign_keys=[user_id])

    def __repr__(self) -> str:  # pragma: no cover
        return f"<FraudFlag user={self.user_id} type={self.flag_type} status={self.status}>"
