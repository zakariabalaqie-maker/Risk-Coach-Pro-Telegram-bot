"""TraderProfile — computed result of the 5-question PROFILE question set (rule #9)."""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, TimestampMixin

if TYPE_CHECKING:
    from app.database.models.user import User


class TraderProfile(TimestampMixin, Base):
    __tablename__ = "trader_profiles"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
    )

    # Derived, human-readable summary fields (computed deterministically by
    # ProfileService from Answer rows — never edited directly).
    experience_label: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    primary_market_label: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    main_challenge_label: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    typical_risk_label: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    preferred_tool_label: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    risk_awareness_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    user: Mapped["User"] = relationship("User", back_populates="profile")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<TraderProfile user={self.user_id} score={self.risk_awareness_score}>"
