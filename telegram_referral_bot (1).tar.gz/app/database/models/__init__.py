"""
Model registry.

Every model MUST be imported here so that `Base.metadata` (used by both
`create_all` for SQLite MVP and by Alembic autogenerate for the future
PostgreSQL migration) sees the full schema.
"""
from app.database.models.admin_log import AdminLog
from app.database.models.base import (
    Base,
    FraudFlagStatus,
    FraudFlagType,
    MembershipStatus,
    ReferralStatus,
    RewardStatus,
    TimestampMixin,
    as_aware_utc,
    utcnow,
)
from app.database.models.campaign import DEFAULT_CAMPAIGN_KEY, CampaignSettings
from app.database.models.fraud import FraudFlag
from app.database.models.profile import TraderProfile
from app.database.models.question import Answer, Question, QuestionOption, QuestionSet
from app.database.models.referral import Referral
from app.database.models.reward import Reward
from app.database.models.user import User

__all__ = [
    "Base",
    "TimestampMixin",
    "utcnow",
    "as_aware_utc",
    "MembershipStatus",
    "ReferralStatus",
    "RewardStatus",
    "FraudFlagType",
    "FraudFlagStatus",
    "User",
    "Referral",
    "TraderProfile",
    "Reward",
    "FraudFlag",
    "AdminLog",
    "CampaignSettings",
    "DEFAULT_CAMPAIGN_KEY",
    "Question",
    "QuestionOption",
    "QuestionSet",
    "Answer",
]
