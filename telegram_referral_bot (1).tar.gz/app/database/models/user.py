"""User model — one row per Telegram user who ever touched the bot."""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.models.base import Base, MembershipStatus, TimestampMixin, utcnow

if TYPE_CHECKING:
    from app.database.models.admin_log import AdminLog
    from app.database.models.profile import TraderProfile
    from app.database.models.referral import Referral
    from app.database.models.reward import Reward


class User(TimestampMixin, Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    # Telegram identity — the only thing we can truly trust from the client.
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    language_code: Mapped[Optional[str]] = mapped_column(String(8), nullable=True)

    # Referral identity of THIS user (as a referrer).
    referral_code: Mapped[str] = mapped_column(String(16), unique=True, index=True, nullable=False)

    # Who referred this user in (nullable = organic / no referrer).
    # Set exactly once, at first /start. Immutable after that (enforced in service layer).
    referred_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    referred_by: Mapped[Optional["User"]] = relationship(
        "User", remote_side=[id], back_populates="referred_users", foreign_keys=[referred_by_id]
    )
    referred_users: Mapped[list["User"]] = relationship(
        "User", back_populates="referred_by", foreign_keys=[referred_by_id]
    )

    # Channel membership (of the campaign's target channel).
    membership_status: Mapped[MembershipStatus] = mapped_column(
        default=MembershipStatus.UNKNOWN, nullable=False
    )
    joined_channel_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    left_channel_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_membership_check_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Onboarding state.
    has_started_bot: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    has_completed_profile: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Campaign counters (denormalized for fast dashboard reads; always
    # derived/recomputed from Referral rows by ReferralService — never the
    # sole source of truth).
    valid_referrals_count: Mapped[int] = mapped_column(default=0, nullable=False)

    # Admin moderation.
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    blocked_reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Admin flag (separate from Telegram's own admin concept).
    is_admin_cached: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    last_active_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    # Relationships
    profile: Mapped[Optional["TraderProfile"]] = relationship(
        "TraderProfile", back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    reward: Mapped[Optional["Reward"]] = relationship(
        "Reward", back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    referrals_made: Mapped[list["Referral"]] = relationship(
        "Referral",
        back_populates="referrer",
        foreign_keys="Referral.referrer_id",
        cascade="all, delete-orphan",
    )
    referral_received: Mapped[Optional["Referral"]] = relationship(
        "Referral",
        back_populates="referred_user",
        foreign_keys="Referral.referred_user_id",
        uselist=False,
    )
    admin_actions: Mapped[list["AdminLog"]] = relationship("AdminLog", back_populates="admin_user")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<User id={self.id} tg_id={self.telegram_id} code={self.referral_code}>"
